@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "SCRIPT=%~dp0A.P.X._CODES\1._A.P.X._SELECTIVE_LOCAL_SYSTEM\1._A.P.X._SELECTIVE_LOCAL_SYSTEM.py"

if not exist "%SCRIPT%" (
    echo ERROR: A.P.X. Python script not found.
    echo Expected: "%SCRIPT%"
    goto failed
)

rem Verify that the interpreter can actually execute code before launching the script.
rem A broken Python launcher may point to an invalid C:\Python314\python.exe.
where py >nul 2>&1
if not errorlevel 1 (
    py -3 -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
    if not errorlevel 1 (
        echo Using Python launcher: py -3
        py -3 "%SCRIPT%"
        set "RESULT=%ERRORLEVEL%"
        goto finish
    )
)

where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
    if not errorlevel 1 (
        echo Using Python command: python
        python "%SCRIPT%"
        set "RESULT=%ERRORLEVEL%"
        goto finish
    )
)

where python3 >nul 2>&1
if not errorlevel 1 (
    python3 -c "import sys; assert sys.version_info >= (3, 10)" >nul 2>&1
    if not errorlevel 1 (
        echo Using Python command: python3
        python3 "%SCRIPT%"
        set "RESULT=%ERRORLEVEL%"
        goto finish
    )
)

echo ERROR: No working Python 3.10+ interpreter was found.
echo Your Python launcher may reference an invalid C:\Python314\python.exe.
echo Check the installation using: py -0p
echo Reinstall or repair Python if all installed interpreters fail.
:failed
set "RESULT=1"
:finish
echo.
if not "%RESULT%"=="0" echo Execution ended with error code %RESULT%.
pause
exit /b %RESULT%
