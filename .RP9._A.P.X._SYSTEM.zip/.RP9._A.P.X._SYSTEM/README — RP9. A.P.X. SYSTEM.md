# README — RP9. A.P.X. SYSTEM
---
## 📂 A.P.X. — SYSTEM

> [!rp9-darkgray]
> 
> ## 📂 A.P.X. — SYSTEM
>
> 📂 **THE A.P.X. SYSTEM GENERATES**
>
> - `+` **M.R.F. ("FILE")** = MACHINE-READABLE FORMAT
> - `+` **index & Links**
>
> 📂 — **0. A.P.X. [Folder Name]**
>
> ***A folder providing two complementary access functions:***
>
> - **M.R.F. + [Folder Name].md**  
>   Aggregates the branch’s source material with source metadata, internal navigation and links to the original files.
>
> - **index & Links. + [Folder Name].md**  
>   Provides folder-grouped navigation to the original files.
>---
> ```ASCII
> 📂 0. A.P.X. + [FOLDER NAME]
>  ↓
> 📑 M.R.F. + [FOLDER NAME]
> 📑 index & Links + [FOLDER NAME]
> ```
> ---
> 
> *The M.R.F. supports consolidated reading and inspection by humans and AI systems.*
>
>*The index provides direct access to individual files. Neither replaces the original source material.*
>
> ---

---
### BAT — AUTOMATED COMMAND EXECUTION

*A **BAT file** is a batch file containing predefined commands that Windows executes in sequence.*

*It automates the steps required to start a program and can present ready-made menu options, allowing the user to select a function without entering commands manually.*

*Within the **A.P.X.** system, **BAT files** launch the Python programs and provide access to their predefined menus for simplicity and ease of use.*

Windows may display a security warning because the file is downloaded or lacks a recognised digital signature. This concerns file recognition and signing, rather than software licensing.

If you recognise the file as part of the A.P.X. system and trust its source, confirm that you want to run it to use the function.

---
## Generate the A.P.X. System
## 📂 FOLDER ARCHITECTURE

```ASCII
📂ⓘ ── Non-submission Appendix
     └─ 📂 RP9._A.P.X._SYSTEM
         └─ 📂 A.P.X._CODES
            └─ 📂 GENERATED
                ↓
                🖥️ 1._A.P.X._SELECTIVE_LOCAL_SYSTEM_FIXED.bat
                🖥️ 2._A.P.X._INTEGRATED_LOCAL_SYSTEM.bat
                🖥️ 3._A.P.X._CLONE_SYSTEM.bat
                ↓
                📑 README — RP9. A.P.X. SYSTEM
```

---

## 🖥️ — 📂 1. A.P.X.

---

> ---
>
> ### 🖥️ — 1._A.P.X._SELECTIVE_LOCAL_SYSTEM_FIXED.bat
>
> ```text
> SOURCE: 📂 1._A.P.X._SELECTIVE_LOCAL_SYSTEM
> ```
>
> > ---
> >
> > - `User-friendly`
> > - `PRESELECTED MENU FUNCTIONS`
> > - `CMD INTERFACE`
>
> ---
>
> ***This option enables the user to choose***  
> ***between the preset options***  
> ***in the CMD interface.***
>
> ---
>
> ***Use this option to create a separate A.P.X. structure***  
> ***in the designated output folder: 📂 GENERATED.***
>
> ---

### **Run BAT 🖥️ 1. A.P.X. CMD**

> [!rp9-darkgray]  $\boxed{\text{Run BAT — EXECUTION \& COMMAND}}$
> 
>---
> ### $$\boxed{\text{▶ Run BAT 🖥️ CMD}}$$
> ---
>
> - #### $\boxed{\text{🖥️ — 1. A.P.X.}}$
>
> ---
>
>## <center><code>▶ Run BAT 🖥️ ⟶ EXECUTION & COMMAND</code></center>
>
> ---
>
>
>🔗 ▶ [[1._A.P.X._SELECTIVE_LOCAL_SYSTEM_FIXED.bat|Run BAT 🖥️ 1. A.P.X. CMD]]

---

## 🖥️ — 📂 2. A.P.X.

---

> ---
>
> ### 🖥️ — 2._A.P.X._INTEGRATED_LOCAL_SYSTEM.bat
>
> ```text
> SOURCE: 📂 2._A.P.X._INTERGRATED_LOCAL_SYSTEM
> ```
>
> > ---
> >
> > - `User-friendly`
> > - `PRESELECTED MENU FUNCTIONS`
> > - `CMD INTERFACE`
>
> ---
>
> ***This option enables the user to choose***  
> ***between the preset integration levels***  
> ***in the CMD interface.***
>
> ---
>
> ***Use this option to create and integrate A.P.X. structures***  
> ***directly within the submission folder:***  
> ***📂 RP9. THE RIEMANN SUBMISSION.***
>
> ---
>
> **ADD & INTEGRATE**
>
> `Add +` 📂 A.P.X. ⟶🔀 📂 RP9. THE RIEMANN SUBMISSION
>
> ---

### **Run BAT 🖥️ 2. A.P.X. CMD**

> [!rp9-darkgray]  $\boxed{\text{Run BAT — EXECUTION \& COMMAND}}$
> 
>---
> ### $$\boxed{\text{▶ Run BAT 🖥️ CMD}}$$
> ---
>
> - #### $\boxed{\text{🖥️ — 2. A.P.X.}}$
>
> ---
>
>## <center><code>▶ Run BAT 🖥️ ⟶ EXECUTION & COMMAND</code></center>
>
> ---
>
> 🔗 ▶ [[2._A.P.X._INTEGRATED_LOCAL_SYSTEM_ASCII.bat|Run BAT 🖥️ 2. A.P.X. CMD]]

---

## 🖥️ — 📂 3. A.P.X.

---

> ---
>
> ### 🖥️ — 3._A.P.X._CLONE_SYSTEM.bat
>
> ```text
> SOURCE: 📂 3._A.P.X._CLONE_RECURSIVE_SYSTEM
> ```
>
> > ---
> >
> > - `User-friendly`
> > - `PRESELECTED MENU FUNCTIONS`
> > - `CMD INTERFACE`
>
> ---
>
> ***This option enables the user to choose***  
> ***between the preset options***  
> ***in the CMD interface.***
>
> ---
>
> ***Use this option to create a separate A.P.X. clone structure***  
> ***in the designated output folder: 📂 GENERATED.***
>
> ---
>
> **ADD & CLONE**
>
> `Add +` 📂 A.P.X. ⟶🔀 📂 GENERATED
>
> ```ASCII
> 📂 GENERATED
>  ↓
> 📂 A.P.X. Clone System
> = (New 📂 A.P.X. Clone)
> ```
>
> ---
> 

### **Run BAT 🖥️ 3. A.P.X. CMD**

> [!rp9-darkgray]  $\boxed{\text{Run BAT — EXECUTION \& COMMAND}}$
> 
>---
> ### $$\boxed{\text{▶ Run BAT 🖥️ CMD}}$$
> ---
> 
> - #### $\boxed{\text{🖥️ — 3. A.P.X.}}$
>
> ---
>
> ## <center><code>▶ Run BAT 🖥️ ⟶ EXECUTION & COMMAND</code></center>
>
> ---
>
>
> 🔗 ▶ [[3._A.P.X._CLONE_SYSTEM.bat|Run BAT 🖥️ 3. A.P.X. CMD]]

---
> ---
>
> ## **END OF DOCUMENT**
>
> ---
---
