@echo off
setlocal EnableExtensions
echo RP9 LAUNCHER - SUPPORT TEXT V4
echo Launcher: "%~f0"
echo.
set "SCRIPT=%~dp0A.P.X._CODES\2._A.P.X._INTERGRATED_LOCAL_SYSTEM\2._A.P.X._INTEGRATED_LOCAL_SYSTEM.py"
if not exist "%SCRIPT%" (
  echo ERROR: Python generator not found.
  echo Expected: "%SCRIPT%"
  pause
  exit /b 1
)
set "SUPPORT_FILE=%~dp0A.P.X._CODES\2._A.P.X._INTERGRATED_LOCAL_SYSTEM\A.P.X._INTERGRATED_LOCAL_SYSTEM_ASCII.txt"
echo Support text: "%SUPPORT_FILE%"
if exist "%SUPPORT_FILE%" (
  echo FOUND: Opening support text in Notepad.
  start "" "%SystemRoot%\System32\notepad.exe" "%SUPPORT_FILE%"
  if errorlevel 1 echo ERROR: Notepad could not be started.
) else (
  echo NOT FOUND: Check the folder and exact filename shown above.
)
echo.
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 (
    py -3 "%SCRIPT%"
    set "RESULT=%ERRORLEVEL%"
    echo.
    pause
    exit /b %RESULT%
  )
)
where python >nul 2>&1
if not errorlevel 1 (
  python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 (
    python "%SCRIPT%"
    set "RESULT=%ERRORLEVEL%"
    echo.
    pause
    exit /b %RESULT%
  )
)
echo ERROR: A working Python 3.10+ installation was not found.
pause
exit /b 1
