@echo off
setlocal EnableExtensions

rem RP9 A.P.X Clone System launcher
rem This BAT file must be placed in RP9._A.P.X._SYSTEM beside GENERATED.
set "SYSTEM_DIR=%~dp0"
for %%I in ("%SYSTEM_DIR%..\..") do set "REPOSITORY_ROOT=%%~fI"
set "SCRIPT=%SYSTEM_DIR%A.P.X._CODES\3._A.P.X._CLONE_SYSTEM\3._A.P.X._CLONE_SYSTEM.py"
set "OUTPUT=%SYSTEM_DIR%GENERATED\A.P.X_Clone_System"

if not exist "%SCRIPT%" (
  echo ERROR: Python script not found:
  echo "%SCRIPT%"
  goto :failed
)

set "PYTHON_CMD="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  python3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=python3"
)
if not defined PYTHON_CMD (
  echo ERROR: No working Python 3.10+ installation found.
  goto :failed
)

echo ================================================================
echo RP9 A.P.X CLONE SYSTEM
echo ================================================================
echo Python: %PYTHON_CMD%
echo Source: "%REPOSITORY_ROOT%"
echo Output: "%OUTPUT%"
echo.
echo This will generate or update the recursive clone in GENERATED.
echo Existing generated files with matching names may be overwritten.
echo.
choice /C YN /M "Continue"
if errorlevel 2 goto :cancel

%PYTHON_CMD% "%SCRIPT%" --source-root "%REPOSITORY_ROOT%" --output-root "%OUTPUT%"
if errorlevel 1 goto :failed

echo.
echo COMPLETED.
pause
exit /b 0

:cancel
echo Cancelled.
pause
exit /b 0

:failed
echo.
echo FAILED. Review the message above.
pause
exit /b 1
