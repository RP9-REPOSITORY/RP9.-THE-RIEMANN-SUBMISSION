# RP9 A.P.X. SELECTIVE LOCAL SYSTEM
# Version 1.0.0 | Python 3.10+
# Source: user-provided RP9 recursive generator v2.2.0, adapted for menu selection.
# Original repository files are read-only. Outputs are written to GENERATED.
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from collections import Counter
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote


# ============================================================
# MRF / A.P.X RECURSIVE MIRROR GENERATOR
# VERSION 2.2.0
# ============================================================
# Place this script in the source root and run it with Python 3.10+.
# Output: A.P.X (<ROOT NAME>)/<mirrored relative folder>/
#         0. A.P.X. <FOLDER NAME>/M.R.F. <FOLDER NAME>.md
#         0. A.P.X. <FOLDER NAME>/A.P.X. SYSTEM INDEX.md
# Process deepest folders first, then the source root.
# Only the folder structure is mirrored; original files stay in place.
# Each MRF aggregates supported original sources in its complete subtree.
# The structure includes every real source folder, including empty and
# hidden folders. Only this output tree and directory symlinks are skipped.
# Source-content filtering remains separate from structure cloning. Existing M.C.A files are never modified or deleted.
# Reruns overwrite generated documents without deleting stale folders.
# Keep the mirror inside the source root so relative links remain valid.
# PDF handling is unchanged: this generator does not extract PDF text.
# ============================================================


# ============================================================
# CONFIGURATION
# ============================================================

SCRIPT_VERSION = "2.2.0"
MRF_SYSTEM_NAME = "MRF — MACHINE-READABLE FORMAT"

ALLOWED_EXTENSIONS = (
    ".md",
    ".txt",
    ".py",
    ".json",
    ".csv",
    ".log",
    ".yaml",
     ".pdf",
    ".yml",
)

APX_FOLDER_TEMPLATE = "0. A.P.X. {BASE_NAME}"
SYSTEM_INDEX_TEMPLATE = "A.P.X. SYSTEM INDEX.md"
# Optional absolute path to your Obsidian vault. None detects an ancestor
# containing .obsidian, falling back to the source root.
OBSIDIAN_VAULT_ROOT: str | None = None
MCA_NAME = "00. M.C.A.md"

# Extra system folder names that shall never be scanned.
# The generated A.P.X folder name is intentionally NOT listed here.
# All generated A.P.X folders are excluded from recursive source scans.
EXCLUDED_FOLDER_NAMES = {
    "00. MASKIN LÄSNING",
    "00. MASKINLÄSNING",
}

# Generated MRF files found below the current root are excluded from
# a new MRF aggregation to prevent redundant machine-readable nesting.
# Other nested A.P.X files remain eligible.
GENERATED_MRF_PREFIXES = (
    "00. M.R.F. ",
    "00.MRF. ",
    "M.R.F. ",
)

# Legacy generated F.R.C folders are excluded if they exist.
EXCLUDED_FOLDER_PREFIXES = (
    "00. MASKINLÄSNING (F.R.C) — ",
)

# Common files that should not become source material.
EXCLUDED_FILE_NAMES = {
    "desktop.ini",
    "00. index & Links.md",
    MCA_NAME,
}

# Optional repository metadata.
REPOSITORY_NAME = "RP9. RH. Z0"

PACKAGE_PURPOSE = (
    "Machine-readable local representation for structured review, "
    "source tracing, cross-document analysis and rapid navigation."
)

PACKAGE_KEYWORDS = [
    "MRF",
    "Machine-Readable Format",
    "A.P.X",
    "A.P.X. SYSTEM INDEX",
    "source tracing",
    "structured review",
]

SCOPE_STATEMENT = (
    "This MRF contains all includable text-based source material found "
    "inside the selected local root folder at execution time. "
    "A.P.X, hidden folders, explicitly excluded system folders, legacy "
    "generated export folders, the running script and unsupported file "
    "types are not included."
)

PAUSE_AT_END = True


# ============================================================
# ROOT / OUTPUT PATHS
# ============================================================

THIS_SCRIPT = Path(__file__).resolve()
SOURCE_ROOT = THIS_SCRIPT.parent
OUTPUT_ROOT = SOURCE_ROOT / f"A.P.X ({SOURCE_ROOT.name})"
ROOT = SOURCE_ROOT
BASE_NAME = ROOT.name
APX_FOLDER_NAME = APX_FOLDER_TEMPLATE.format(BASE_NAME=BASE_NAME)
SYSTEM_INDEX_NAME = SYSTEM_INDEX_TEMPLATE.format(BASE_NAME=BASE_NAME)
EXCLUDED_FILE_NAMES.add(SYSTEM_INDEX_NAME)

APX_PATH = OUTPUT_ROOT / APX_FOLDER_NAME

MRF_NAME = f"M.R.F. {BASE_NAME}.md"
MRF_PATH = APX_PATH / MRF_NAME
SYSTEM_INDEX_PATH = APX_PATH / SYSTEM_INDEX_NAME
MCA_PATH = APX_PATH / MCA_NAME


# ============================================================
# DATA MODEL
# ============================================================

@dataclass
class SourceRecord:
    sequence: int
    filename: str
    relative_path: str
    extension: str
    size_bytes: int
    modified_local: str
    line_count: int
    word_count: int
    character_count: int
    sha256: str
    anchor: str
    encoding: str
    read_error: str | None = None


# ============================================================
# SORTING / FILTERING
# ============================================================

def natural_sort_key(value: str) -> list[object]:
    return [
        int(part) if part.isdigit() else part.casefold()
        for part in re.split(r"(\d+)", value)
    ]


def is_hidden_name(name: str) -> bool:
    return name.startswith(".")


def is_excluded_directory(path: Path) -> bool:
    name = path.name

    if path.is_symlink() or path.resolve() == OUTPUT_ROOT.resolve():
        return True
    if name.startswith(("0. A.P.X", "000. A.P.X", "A.P.X (")):
        return True

    if is_hidden_name(name):
        return True

    # Also exclude the active output folder explicitly.
    try:
        if path.resolve() == APX_PATH.resolve():
            return True
    except OSError:
        pass

    if name in EXCLUDED_FOLDER_NAMES:
        return True

    if any(name.startswith(prefix) for prefix in EXCLUDED_FOLDER_PREFIXES):
        return True

    return False


def is_allowed_source_file(path: Path) -> bool:
    if path.is_symlink() or not path.is_file():
        return False

    if path.resolve() == THIS_SCRIPT:
        return False

    if path.name in EXCLUDED_FILE_NAMES:
        return False

    if is_hidden_name(path.name):
        return False

    # MRF-only exclusion:
    # do not merge nested generated MRF documents into a higher-level MRF.
    if (
        path.suffix.casefold() == ".md"
        and any(path.name.startswith(prefix) for prefix in GENERATED_MRF_PREFIXES)
    ):
        return False

    # Exclude this root's own generated A.P.X output.
    try:
        if APX_PATH.resolve() in path.resolve().parents:
            return False
    except OSError:
        pass

    return path.suffix.casefold() in ALLOWED_EXTENSIONS


def collect_source_paths(root: Path) -> list[Path]:
    collected: list[Path] = []

    for dirpath, dirnames, filenames in os.walk(root):
        current_dir = Path(dirpath)

        dirnames[:] = sorted(
            [
                dirname
                for dirname in dirnames
                if not is_excluded_directory(current_dir / dirname)
            ],
            key=natural_sort_key,
        )

        for filename in sorted(filenames, key=natural_sort_key):
            path = current_dir / filename

            if is_allowed_source_file(path):
                collected.append(path)

    return collected


# ============================================================
# READING / ANALYSIS
# ============================================================

def read_text_robust(path: Path) -> tuple[str, str]:
    encodings = (
        "utf-8-sig",
        "utf-8",
        "cp1252",
        "latin-1",
    )

    last_error: Exception | None = None

    for encoding in encodings:
        try:
            return path.read_text(encoding=encoding), encoding
        except UnicodeDecodeError as error:
            last_error = error
        except OSError:
            raise

    raise UnicodeError(
        f"Could not decode file. Last error: {last_error}"
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()

    with path.open("rb") as file_handle:
        for block in iter(lambda: file_handle.read(1024 * 1024), b""):
            digest.update(block)

    return digest.hexdigest()


def count_words(text: str) -> int:
    return len(re.findall(r"\S+", text))


def make_anchor(relative_path: str) -> str:
    normalized = relative_path.replace("\\", "/").strip()
    slug = normalized.casefold()

    slug = re.sub(r"\.[a-z0-9]+$", "", slug)
    slug = re.sub(r"[^a-z0-9åäöæøüß]+", "-", slug)
    slug = re.sub(r"-+", "-", slug).strip("-")

    if not slug:
        slug = "source"

    short_hash = hashlib.sha1(
        normalized.encode("utf-8")
    ).hexdigest()[:10]

    return f"mrf-{slug}-{short_hash}"


def analyze_sources(
    paths: list[Path],
) -> tuple[list[SourceRecord], dict[str, str]]:
    records: list[SourceRecord] = []
    contents: dict[str, str] = {}

    for sequence, path in enumerate(paths, start=1):
        relative_path = path.relative_to(ROOT).as_posix()
        stat = path.stat()

        read_error: str | None = None
        text = ""
        encoding = "unread"

        try:
            text, encoding = read_text_robust(path)
        except Exception as error:
            read_error = f"{type(error).__name__}: {error}"
            text = (
                "MRF READ ERROR\n\n"
                f"Source: {relative_path}\n\n"
                f"Error: {read_error}\n"
            )

        record = SourceRecord(
            sequence=sequence,
            filename=path.name,
            relative_path=relative_path,
            extension=path.suffix.casefold(),
            size_bytes=stat.st_size,
            modified_local=datetime.fromtimestamp(
                stat.st_mtime
            ).astimezone().isoformat(timespec="seconds"),
            line_count=text.count("\n") + (1 if text else 0),
            word_count=count_words(text),
            character_count=len(text),
            sha256=sha256_file(path),
            anchor=make_anchor(relative_path),
            encoding=encoding,
            read_error=read_error,
        )

        records.append(record)
        contents[relative_path] = text

    return records, contents


# ============================================================
# STRUCTURE DATA
# ============================================================

def build_json_tree(records: list[SourceRecord]) -> dict:
    tree: dict = {}

    for record in records:
        parts = Path(record.relative_path).parts
        pointer = tree

        for folder in parts[:-1]:
            pointer = pointer.setdefault(folder, {})

        pointer.setdefault("_files", []).append(parts[-1])

    def sort_tree(node: dict) -> dict:
        sorted_node: dict = {}

        for key in sorted(
            (key for key in node if key != "_files"),
            key=natural_sort_key,
        ):
            sorted_node[key] = sort_tree(node[key])

        if "_files" in node:
            sorted_node["_files"] = sorted(
                node["_files"],
                key=natural_sort_key,
            )

        return sorted_node

    return sort_tree(tree)


def build_ascii_tree(records: list[SourceRecord]) -> list[str]:
    tree = build_json_tree(records)

    def render_node(node: dict, prefix: str = "") -> list[str]:
        lines: list[str] = []

        folder_names = [
            key for key in node.keys() if key != "_files"
        ]
        filenames = node.get("_files", [])

        entries: list[tuple[str, str, dict | None]] = []
        entries.extend(
            ("folder", name, node[name])
            for name in folder_names
        )
        entries.extend(
            ("file", name, None)
            for name in filenames
        )

        for index, (entry_type, name, child) in enumerate(entries):
            is_last = index == len(entries) - 1
            connector = "└── " if is_last else "├── "
            lines.append(f"{prefix}{connector}{name}")

            if entry_type == "folder" and child is not None:
                extension = "    " if is_last else "│   "
                lines.extend(
                    render_node(child, prefix + extension)
                )

        return lines

    return [BASE_NAME, ""] + render_node(tree)


# ============================================================
# MARKDOWN HELPERS
# ============================================================

def human_size(size_bytes: int) -> str:
    value = float(size_bytes)

    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024 or unit == "GB":
            if unit == "B":
                return f"{int(value)} {unit}"
            return f"{value:.2f} {unit}"
        value /= 1024

    return f"{size_bytes} B"


def markdown_escape_table(value: object) -> str:
    return str(value).replace("|", r"\|").replace("\n", " ")


def safe_code_fence(content: str, language: str) -> str:
    matches = re.findall(r"`+", content)
    longest = max((len(match) for match in matches), default=0)
    fence = "`" * max(3, longest + 1)

    return f"{fence}{language}\n{content.rstrip()}\n{fence}"


def format_source_content(
    record: SourceRecord,
    content: str,
) -> str:
    if record.extension == ".md":
        return content.rstrip()

    language_by_extension = {
        ".txt": "text",
        ".py": "python",
        ".json": "json",
        ".csv": "csv",
        ".log": "text",
        ".yaml": "yaml",
        ".yml": "yaml",
    }

    language = language_by_extension.get(
        record.extension,
        "text",
    )

    return safe_code_fence(content, language)


# ============================================================
# MRF METADATA
# ============================================================

def build_metadata(
    records: list[SourceRecord],
    generated_at: datetime,
) -> dict:
    extension_counts = Counter(
        record.extension for record in records
    )

    error_count = sum(
        record.read_error is not None
        for record in records
    )

    folder_paths = {
        str(Path(record.relative_path).parent)
        for record in records
        if str(Path(record.relative_path).parent) != "."
    }

    return {
        "mrf_system": MRF_SYSTEM_NAME,
        "generator_version": SCRIPT_VERSION,
        "repository": REPOSITORY_NAME or BASE_NAME,
        "package_name": BASE_NAME,
        "package_purpose": PACKAGE_PURPOSE,
        "source_root": str(ROOT),
        "apx_folder": APX_FOLDER_NAME,
        "generated_at_local": (
            generated_at.astimezone().isoformat(
                timespec="seconds"
            )
        ),
        "generated_at_utc": (
            generated_at.astimezone(timezone.utc).isoformat(
                timespec="seconds"
            )
        ),
        "output_mrf": MRF_NAME,
        "output_system_index": SYSTEM_INDEX_NAME,
        "source_file_count": len(records),
        "source_folder_count": len(folder_paths),
        "total_source_bytes": sum(
            record.size_bytes for record in records
        ),
        "total_characters": sum(
            record.character_count for record in records
        ),
        "total_words": sum(
            record.word_count for record in records
        ),
        "total_lines": sum(
            record.line_count for record in records
        ),
        "read_error_count": error_count,
        "extensions": dict(
            sorted(extension_counts.items())
        ),
        "keywords": PACKAGE_KEYWORDS,
        "scope": SCOPE_STATEMENT,
    }


# ============================================================
# BUILD MRF DOCUMENT
# ============================================================

def build_mrf_document(
    records: list[SourceRecord],
    contents: dict[str, str],
    metadata: dict,
) -> str:
    lines: list[str] = []

    # --------------------------------------------------------
    # 1. IDENTITY
    # --------------------------------------------------------

    lines.extend(
        [
            f"# M.R.F. {BASE_NAME}",
            "",
            "## MACHINE-READABLE FORMAT",
            "",
            f"> **System:** {MRF_SYSTEM_NAME}",
            ">",
            f"> **Package:** {BASE_NAME}",
            ">",
            f"> **Generator:** v{SCRIPT_VERSION}",
            "",
            "---",
            "",
            "## PACKAGE COMPONENTS",
            "",
            "This generated package consists of two complementary files:",
            "",
            f"- **{MRF_NAME}** — source aggregation, metadata and internal navigation.",
            f"- **{SYSTEM_INDEX_NAME}** — navigation within the A.P.X system.",
            "",
            "System navigation links only to generated A.P.X folders and documents. "
            "The index itself is not included as source material.",
            "",
            "---",
            "",
            "## MRF METADATA",
            "",
            "```json",
            json.dumps(
                metadata,
                indent=4,
                ensure_ascii=False,
            ),
            "```",
            "",
            "---",
            "",
        ]
    )

    # --------------------------------------------------------
    # 2. SCOPE
    # --------------------------------------------------------

    lines.extend(
        [
            "## SCOPE",
            "",
            SCOPE_STATEMENT,
            "",
            "### Inclusion",
            "",
            (
                f"- Included source files: "
                f"**{metadata['source_file_count']}**"
            ),
            (
                f"- Included source folders: "
                f"**{metadata['source_folder_count']}**"
            ),
            (
                f"- Included source size: "
                f"**{human_size(metadata['total_source_bytes'])}**"
            ),
            (
                f"- Approximate word count: "
                f"**{metadata['total_words']}**"
            ),
            (
                f"- Read errors: "
                f"**{metadata['read_error_count']}**"
            ),
            "",
            "### Source authority",
            "",
            (
                "The material below is a sequential aggregation "
                "of the original source files."
            ),
            (
                "Each source remains identified by its complete "
                "relative path, filename, type, modification time "
                "and SHA-256 checksum."
            ),
            "",
            (
                "The MRF is a machine-readable review and transport "
                "representation."
            ),
            "It does not replace the original source files.",
            "",
            "---",
            "",
        ]
    )

    # --------------------------------------------------------
    # 3. MACHINE READING ORIENTATION
    # --------------------------------------------------------

    lines.extend(
        [
            "## MACHINE-READING ORIENTATION",
            "",
            (
                "Use the following hierarchy when locating and "
                "interpreting source material:"
            ),
            "",
            (
                "1. Use the **Document Manifest** to identify "
                "the relevant source."
            ),
            (
                "2. Use the complete relative path as the "
                "source's primary identity."
            ),
            (
                "3. Treat repeated filenames such as README.md "
                "as separate documents."
            ),
            (
                "4. Use the source boundary blocks to distinguish "
                "one source from another."
            ),
            (
                "5. Preserve repository order when reconstructing "
                "sequences or derivations."
            ),
            (
                "6. Attribute statements to the original relative "
                "source path."
            ),
            "",
            "---",
            "",
        ]
    )

    # --------------------------------------------------------
    # 4. JSON STRUCTURE
    # --------------------------------------------------------

    lines.extend(
        [
            "## JSON STRUCTURE",
            "",
            "```json",
            json.dumps(
                build_json_tree(records),
                indent=4,
                ensure_ascii=False,
            ),
            "```",
            "",
            "---",
            "",
        ]
    )

    # --------------------------------------------------------
    # 5. DOCUMENT MANIFEST
    # --------------------------------------------------------

    lines.extend(
        [
            "## 🔗 INTERNAL NAVIGATION — WITHIN THIS M.R.F.",
            "",
            "**SCOPE:**",
            "",
            f"- {MRF_NAME}",
            "",
            "### DOCUMENT MANIFEST",
            "",
            "Both navigation columns open the same source within this M.R.F. "
            "Use Obsidian for heading links or GitHub / HTML for custom anchor links. "
            "HTML links require a renderer that preserves named anchors.",
            "",
            (
                "| Seq. | Source path | Obsidian | GitHub / HTML | Type | Size | Words | "
                "Lines | SHA-256 |"
            ),
            "|---:|:---|:---|:---|:---:|---:|---:|---:|:---|",
        ]
    )

    for record in records:
        lines.append(
            "| "
            f"{record.sequence} | "
            f"{markdown_escape_table(record.relative_path)} | "
            f"[[#SOURCE {record.sequence:04d} — "
            f"{markdown_escape_table(record.filename)}\\|Open]] | "
            f"[Open](#{record.anchor}) | "
            f"{markdown_escape_table(record.extension)} | "
            f"{human_size(record.size_bytes)} | "
            f"{record.word_count} | "
            f"{record.line_count} | "
            f"`{record.sha256[:16]}…` |"
        )

    lines.extend(["", "---", ""])

    # --------------------------------------------------------
    # 6. ASCII TREE
    # --------------------------------------------------------

    lines.extend(
        [
            "## ASCII TREE",
            "",
            "```text",
            *build_ascii_tree(records),
            "```",
            "",
            "---",
            "",
        ]
    )

    # Source-file navigation uses only the sources represented in this M.R.F.
    lines.extend(["## A.P.X. SYSTEM NAVIGATION", "",
                  f"- {system_link(SYSTEM_INDEX_PATH)}", "", "---", ""])

    # --------------------------------------------------------
    # 7. MERGED SOURCE CONTENT
    # --------------------------------------------------------

    lines.extend(
        [
            "# MERGED SOURCE CONTENT",
            "",
            (
                "The following sections preserve the deterministic "
                "source order defined in the Document Manifest."
            ),
            "",
            "---",
            "",
        ]
    )

    for record in records:
        content = contents[record.relative_path]
        formatted_content = format_source_content(
            record,
            content,
        )

        lines.extend(
            [
                f'<a id="{record.anchor}" name="{record.anchor}"></a>',
                "",
                "<!-- MRF_SOURCE_BEGIN -->",
                "",
                (
                    f"## SOURCE {record.sequence:04d} — "
                    f"{record.filename}"
                ),
                "",
                (
                    f"**Relative path:** "
                    f"`{record.relative_path}`  "
                ),
                (
                    f"**File type:** "
                    f"`{record.extension}`  "
                ),
                (
                    f"**Encoding:** "
                    f"`{record.encoding}`  "
                ),
                (
                    f"**Size:** "
                    f"`{record.size_bytes}` bytes  "
                ),
                (
                    f"**Modified:** "
                    f"`{record.modified_local}`  "
                ),
                (
                    f"**SHA-256:** "
                    f"`{record.sha256}`  "
                ),
                (
                    f"**Words:** "
                    f"`{record.word_count}`  "
                ),
                (
                    f"**Lines:** "
                    f"`{record.line_count}`"
                ),
                "",
            ]
        )

        if record.read_error:
            lines.extend(
                [
                    (
                        f"**Read status:** ERROR — "
                        f"`{record.read_error}`"
                    ),
                    "",
                ]
            )
        else:
            lines.extend(
                [
                    "**Read status:** COMPLETE",
                    "",
                ]
            )

        lines.extend(
            [
                "---",
                "",
                formatted_content,
                "",
                "---",
                "",
                (
                    f"## END SOURCE "
                    f"{record.sequence:04d} — "
                    f"{record.filename}"
                ),
                "",
                "<!-- MRF_SOURCE_END -->",
                "",
                "---",
                "",
            ]
        )

    # --------------------------------------------------------
    # 8. COMPLETION RECORD
    # --------------------------------------------------------

    lines.extend(
        [
            "# MRF COMPLETION RECORD",
            "",
            f"- Package: **{BASE_NAME}**",
            f"- Included sources: **{len(records)}**",
            (
                f"- Read errors: "
                f"**{metadata['read_error_count']}**"
            ),
            (
                f"- Generated: "
                f"**{metadata['generated_at_local']}**"
            ),
            "",
            "The machine-readable aggregation is complete.",
            "",
        ]
    )

    return "\n".join(lines).rstrip() + "\n"


# ============================================================
# A.P.X. SYSTEM INDEX
# ============================================================

def obsidian_vault_root() -> Path:
    if OBSIDIAN_VAULT_ROOT is not None:
        return Path(OBSIDIAN_VAULT_ROOT).expanduser().resolve()
    for candidate in (SOURCE_ROOT, *SOURCE_ROOT.parents):
        if (candidate / ".obsidian").is_dir():
            return candidate
    return SOURCE_ROOT


def system_markdown_link(path: Path, label: str = "Open") -> str:
    """Portable, encoded link from the current generated APX folder."""
    path.resolve().relative_to(OUTPUT_ROOT.resolve())
    target = Path(os.path.relpath(path, APX_PATH)).as_posix()
    return f"[{label}]({quote(target, safe='/')})"


def system_obsidian_link(path: Path, label: str = "Open", table: bool = False) -> str:
    """Unencoded, vault-relative wikilink with an explicit alias."""
    path.resolve().relative_to(OUTPUT_ROOT.resolve())
    target = path.resolve().relative_to(obsidian_vault_root())
    if path.suffix.casefold() == ".md":
        target = target.with_suffix("")
    separator = "\\|" if table else "|"
    return f"[[{target.as_posix()}{separator}{label}]]"


def system_link(path: Path) -> str:
    """Dual navigation outside Markdown tables."""
    return (f"Obsidian: {system_obsidian_link(path)} · "
            f"GitHub / HTML: {system_markdown_link(path)}")


def build_system_index(packages: list[tuple[Path, Path]]) -> str:
    """Table navigation only to generated APX packages and their documents."""
    lines = ["# A.P.X. SYSTEM INDEX", "", f"**Scope:** {BASE_NAME}", "",
             "Folder entries open the folder's A.P.X. SYSTEM INDEX.", "",
             "| Seq. | System path | Obsidian | GitHub / HTML | Type |",
             "|---:|:---|:---|:---|:---:|"]
    sequence = 0
    for mrf, index in packages:
        folder = mrf.parent
        for display_path, target, kind in (
            (folder, index, "Folder"),
            (mrf, mrf, "M.R.F."),
            (index, index, "SYSTEM INDEX"),
        ):
            sequence += 1
            relative = display_path.relative_to(OUTPUT_ROOT).as_posix()
            label = "Open index" if kind == "Folder" else "Open"
            lines.append(
                f"| {sequence} | {markdown_escape_table(relative)} | "
                f"{system_obsidian_link(target, label, table=True)} | "
                f"{system_markdown_link(target, label)} | {kind} |"
            )
    return "\n".join(lines).rstrip() + "\n"


# ============================================================
# ATOMIC WRITE
# ============================================================

def atomic_write_text(
    path: Path,
    text: str,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_suffix(path.suffix + ".tmp")

    temporary_path.write_text(
        text,
        encoding="utf-8",
        newline="\n",
    )

    os.replace(temporary_path, path)


# ============================================================
# MAIN PROCESS
# ============================================================

def set_folder_context(source_folder: Path) -> None:
    """Select the source subtree and its corresponding mirror destination."""
    global ROOT, BASE_NAME, APX_FOLDER_NAME, SYSTEM_INDEX_NAME
    global APX_PATH, MRF_NAME, MRF_PATH, SYSTEM_INDEX_PATH, MCA_PATH
    ROOT = source_folder
    BASE_NAME = ROOT.name
    APX_FOLDER_NAME = APX_FOLDER_TEMPLATE.format(BASE_NAME=BASE_NAME)
    SYSTEM_INDEX_NAME = SYSTEM_INDEX_TEMPLATE.format(BASE_NAME=BASE_NAME)
    APX_PATH = OUTPUT_ROOT / ROOT.relative_to(SOURCE_ROOT) / APX_FOLDER_NAME
    MRF_NAME = f"M.R.F. {BASE_NAME}.md"
    MRF_PATH = APX_PATH / MRF_NAME
    SYSTEM_INDEX_PATH = APX_PATH / SYSTEM_INDEX_NAME
    MCA_PATH = APX_PATH / MCA_NAME


def collect_source_folders() -> list[Path]:
    """Snapshot the complete real folder structure, independently of file filters."""
    folders: list[Path] = []
    def scan_error(error: OSError) -> None:
        raise error
    for dirpath, dirnames, _ in os.walk(SOURCE_ROOT, onerror=scan_error):
        current = Path(dirpath)
        dirnames[:] = sorted(
            [name for name in dirnames
             if not (current / name).is_symlink()
             and (current / name).resolve() != OUTPUT_ROOT.resolve()],
            key=natural_sort_key,
        )
        folders.append(current)
    return sorted(folders, key=lambda path: (
        -len(path.relative_to(SOURCE_ROOT).parts),
        natural_sort_key(path.relative_to(SOURCE_ROOT).as_posix()),
    ))


def generate_apx() -> tuple[Path, Path]:
    folders = collect_source_folders()
    # Materialize the entire mirror first, including every leaf and empty folder.
    # No original file is copied into this tree.
    for folder in folders:
        (OUTPUT_ROOT / folder.relative_to(SOURCE_ROOT)).mkdir(parents=True, exist_ok=True)
    completed: dict[Path, tuple[Path, Path]] = {}
    print(f"A.P.X RECURSIVE MIRROR GENERATOR v{SCRIPT_VERSION}")
    print(f"SOURCE: {SOURCE_ROOT}")
    print(f"OUTPUT: {OUTPUT_ROOT}")
    print(f"FOLDERS: {len(folders)}")
    total_errors = 0
    for position, folder in enumerate(folders, start=1):
        set_folder_context(folder)
        records, contents = analyze_sources(collect_source_paths(ROOT))
        metadata = build_metadata(records, datetime.now().astimezone())
        total_errors += metadata["read_error_count"]
        atomic_write_text(MRF_PATH, build_mrf_document(records, contents, metadata))
        packages = [(MRF_PATH, SYSTEM_INDEX_PATH)]
        for descendant, documents in completed.items():
            if ROOT in descendant.parents:
                packages.append(documents)
        atomic_write_text(SYSTEM_INDEX_PATH, build_system_index(packages))
        # Remove only this generator's previous index filename in its output tree.
        legacy_index = APX_PATH / f"index & Links. {BASE_NAME}.md"
        if legacy_index.is_file() and not legacy_index.is_symlink():
            legacy_index.unlink()
        completed[folder] = (MRF_PATH, SYSTEM_INDEX_PATH)
        print(f"[{position}/{len(folders)}] {folder.relative_to(SOURCE_ROOT)} "
              f"— {len(records)} sources; {metadata['read_error_count']} read errors")
    print(f"COMPLETE: {len(folders)} folders; {total_errors} subtree read errors")
    print(f"ROOT INDEX: {SYSTEM_INDEX_PATH}")
    return MRF_PATH, SYSTEM_INDEX_PATH


def pause_if_requested() -> None:
    if not PAUSE_AT_END:
        return

    if sys.stdin is not None and sys.stdin.isatty():
        try:
            input("Press ENTER to close...")
        except EOFError:
            pass



# ============================================================
# SELECTIVE MENU AND REPOSITORY DISCOVERY
# ============================================================

from pathlib import Path as _Path

SELECTIVE_SCRIPT = _Path(__file__).resolve()
SYSTEM_DIR = SELECTIVE_SCRIPT.parent.parent.parent
APPENDIX_DIR = SYSTEM_DIR.parent
REPOSITORY_ROOT = APPENDIX_DIR.parent
GENERATED_ROOT = SYSTEM_DIR / "GENERATED"

MAIN_BRANCHES = (
    "A. RP9. THE RIEMANN SUBMISSION",
    "B. CODE ARCHITECTURE",
    "C. RP9. SUBMISSION. SUPPORT & APPENDIXES",
    "D. RP9. SUBMISSION. FINAL REVIEW",
)
CODE_BRANCHES = ("K.6 CODE ARCHITECTURE", "K.7 CODE ARCHITECTURE", "K.8 CODE ARCHITECTURE")

def resolve_branch(root: _Path, expected: str) -> _Path | None:
    # Match exact name first; allow a single variant with punctuation differences.
    direct = root / expected
    if direct.is_dir():
        return direct
    import re as _re
    norm = lambda x: _re.sub(r"[^a-z0-9]+", "", x.casefold())
    matches = [p for p in root.iterdir() if p.is_dir() and norm(p.name) == norm(expected)]
    return matches[0] if len(matches) == 1 else None

def available_choices() -> dict[str, tuple[str, _Path | None]]:
    choices = {"0": ("COMPLETE RP9 REPOSITORY", REPOSITORY_ROOT)}
    for i, name in enumerate(MAIN_BRANCHES, 1):
        choices[str(i)] = (name, resolve_branch(REPOSITORY_ROOT, name))
    code_root = choices["2"][1]
    for i, name in enumerate(CODE_BRANCHES, 5):
        choices[str(i)] = (name, resolve_branch(code_root, name) if code_root else None)
    return choices

def select_source() -> _Path | None:
    if not APPENDIX_DIR.is_dir() or not REPOSITORY_ROOT.is_dir():
        raise RuntimeError("Cannot resolve the repository from the A.P.X. system directory.")
    choices = available_choices()
    while True:
        print("\n" + "=" * 64)
        print("RP9. A.P.X. SELECTIVE LOCAL SYSTEM — SOURCE SELECTION")
        print("=" * 64)
        for key, (label, path) in choices.items():
            print(f"[{key}] {label}" + ("" if path and path.is_dir() else " [NOT FOUND]"))
        print("[8] SELECT ANY DIRECTORY")
        print("[Q] QUIT")
        answer = input("Selection: ").strip().upper()
        if answer == "Q":
            return None
        if answer == "8":
            raw = input("Absolute directory path: ").strip().strip('"')
            source = _Path(raw).expanduser().resolve()
        elif answer in choices:
            source = choices[answer][1]
            if source is None:
                print("The selected branch was not found. No output created.")
                continue
        else:
            print("Invalid selection.")
            continue
        if not source.is_dir():
            print("Directory does not exist.")
            continue
        if source == GENERATED_ROOT or GENERATED_ROOT in source.parents:
            print("Generated output cannot be used as a source.")
            continue
        print(f"\nSOURCE: {source}")
        print(f"OUTPUT: {GENERATED_ROOT / ('A.P.X (' + source.name + ')')}")
        if input("Generate this selection? [Y/N]: ").strip().upper() == "Y":
            return source

def main() -> int:
    global SOURCE_ROOT, OUTPUT_ROOT, ROOT, THIS_SCRIPT, PAUSE_AT_END, OBSIDIAN_VAULT_ROOT
    source = select_source()
    if source is None:
        return 0
    SOURCE_ROOT = source
    ROOT = source
    THIS_SCRIPT = SELECTIVE_SCRIPT
    OUTPUT_ROOT = GENERATED_ROOT / f"A.P.X ({source.name})"
    PAUSE_AT_END = False
    OBSIDIAN_VAULT_ROOT = str(REPOSITORY_ROOT)
    # Prevent selecting a parent of the output directory other than the repository itself;
    # recursive scanner already excludes OUTPUT_ROOT, but other generated packages must
    # also be excluded to avoid generated content being reprocessed.
    global is_excluded_directory
    original_excluded = is_excluded_directory
    def selective_excluded(path):
        resolved = path.resolve()
        return (resolved == GENERATED_ROOT.resolve() or
                original_excluded(path))
    is_excluded_directory = selective_excluded
    global collect_source_folders
    original_collect = collect_source_folders
    def selective_collect():
        folders = original_collect()
        return [p for p in folders if GENERATED_ROOT.resolve() not in (p.resolve(), *p.resolve().parents)]
    collect_source_folders = selective_collect
    generate_apx()
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\nCancelled.")
        raise SystemExit(1)
    except Exception as error:
        print(f"ERROR: {type(error).__name__}: {error}")
        raise SystemExit(1)
