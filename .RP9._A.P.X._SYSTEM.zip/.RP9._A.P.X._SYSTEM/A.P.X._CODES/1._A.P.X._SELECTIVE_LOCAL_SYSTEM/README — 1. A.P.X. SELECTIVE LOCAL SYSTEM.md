# README — 1. A.P.X. SELECTIVE LOCAL SYSTEM

## PURPOSE

Creates a separate A.P.X. representation of a selected folder and its subfolders for consolidated reading and navigation.

The original files remain in their existing locations.

## START

Run:

**1._A.P.X._SELECTIVE_LOCAL_SYSTEM_FIXED.bat**

The BAT file starts the Python program and opens its selection menu.

**Requirement:** Python 3.10 or newer.

## MENU OPTIONS

| Selection | Source |
|---|---|
| **0** | Complete submission root |
| **1** | A. RP9. THE RIEMANN SUBMISSION |
| **2** | B. CODE ARCHITECTURE |
| **3** | C. RP9. SUBMISSION. SUPPORT & APPENDIXES |
| **4** | D. RP9. SUBMISSION. FINAL REVIEW |
| **5** | K.6 CODE ARCHITECTURE |
| **6** | K.7 CODE ARCHITECTURE |
| **7** | K.8 CODE ARCHITECTURE |
| **8** | Another directory, entered as an absolute path |
| **Q** | Quit |

The program displays the selected source and output location. Enter **Y** to generate the selection or **N** to return to the menu.

## GENERATED OUTPUT

Results are placed in:

**RP9._A.P.X._SYSTEM/GENERATED/A.P.X ([Selected Folder Name])**

The selected folder structure is reproduced, with an A.P.X. folder at each represented level:

```text
0. A.P.X. [Folder Name]
├── M.R.F. [Folder Name].md
└── A.P.X. SYSTEM INDEX.md
```

- **M.R.F.** aggregates the supported source content within that folder and its subfolders.
- **A.P.X. SYSTEM INDEX** provides navigation within the generated A.P.X. structure.

Processing proceeds from the deepest folders up to the selected root.

## REPEATED USE

Running the same selection again updates its generated documents in the same output location. Original source files remain unchanged.

