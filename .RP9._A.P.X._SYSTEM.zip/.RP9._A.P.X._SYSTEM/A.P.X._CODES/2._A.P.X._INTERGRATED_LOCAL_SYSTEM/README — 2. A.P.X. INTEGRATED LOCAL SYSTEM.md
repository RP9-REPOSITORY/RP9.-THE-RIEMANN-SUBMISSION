# README — 2. A.P.X. INTEGRATED LOCAL SYSTEM

## PURPOSE

Creates A.P.X. folders directly within the existing submission structure at the selected integration level.

The original source files remain in their existing locations.

## START

Run:

**2._A.P.X._INTEGRATED_LOCAL_SYSTEM_ASCII.bat**

The BAT file starts the Python program and opens its selection menu. If available, the accompanying ASCII support file also opens in Notepad.

**Requirement:** Python 3.10 or newer.

## MENU OPTIONS

| Selection | Integration scope |
|---|---|
| **A / 1** | The four main branches: A, B, C and D |
| **B / 2** | K.6, K.7 and K.8 CODE ARCHITECTURE within branch B |
| **C / 3** | The submission root and all eligible subfolders, processed recursively |
| **Q** | Quit |

The program displays the target folders before writing any files. Enter **Y** to proceed or **N** to return to the menu.

## GENERATED OUTPUT

Each target folder receives:

```text
[Target Folder]
└── 0. A.P.X. [Folder Name]
    ├── M.R.F. [Folder Name].md
    └── A.P.X. SYSTEM INDEX.md
```

- **M.R.F.** aggregates the supported source content within that folder and its subfolders.
- **A.P.X. SYSTEM INDEX** provides navigation to the generated A.P.X. documents. At Level 3, it also includes the generated documents in descendant folders.

Output is integrated directly into the selected locations, rather than placed in **GENERATED**.

## RECURSIVE INTEGRATION

Level 3 processes eligible folders from the deepest level up to the submission root.

The Non-submission Appendix, GENERATED, existing A.P.X. folders and other excluded system folders are omitted from integration and source collection.

## REPEATED USE

Running an integration again overwrites the corresponding generated M.R.F. and system index files.

Original source files remain unchanged.

