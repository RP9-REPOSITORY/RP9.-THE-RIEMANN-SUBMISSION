# README — 3. A.P.X. CLONE SYSTEM

## PURPOSE

Creates a separate A.P.X. representation of the complete submission folder structure, including its deepest and empty folders.

The folder structure is cloned without copying the original source files. Their supported content is collected in generated M.R.F. documents.

## START

Run:

**3._A.P.X._CLONE_SYSTEM.bat**

The BAT file starts the Python program using the submission root as its source.

**Requirement:** Python 3.10 or newer.

## CONFIRMATION

The launcher displays the source and output locations.

- Enter **Y** to generate the clone.
- Enter **N** to cancel.

This option processes the complete source structure without a branch-selection menu.

## GENERATED OUTPUT

Results are placed in:

**RP9._A.P.X._SYSTEM/GENERATED/A.P.X_Clone_System**

Each corresponding folder in the cloned structure receives:

```text
0. A.P.X. [Folder Name]
├── M.R.F. [Folder Name].md
└── A.P.X. SYSTEM INDEX.md
```

- **M.R.F.** aggregates the supported source content within the corresponding folder and its subfolders.
- **A.P.X. SYSTEM INDEX** provides navigation to the generated A.P.X. folders and documents.

Processing proceeds from the deepest folders up to the source root.

## SCOPE

The clone includes the Non-submission Appendix and other existing source folders.

The GENERATED output directory and directory symbolic links are excluded from structure cloning. Source-content collection applies its own file and folder exclusions.

## REPEATED USE

Running the launcher again updates generated documents in the same output structure. Existing folders are not automatically removed when their source folders disappear.

Original source files remain unchanged.

