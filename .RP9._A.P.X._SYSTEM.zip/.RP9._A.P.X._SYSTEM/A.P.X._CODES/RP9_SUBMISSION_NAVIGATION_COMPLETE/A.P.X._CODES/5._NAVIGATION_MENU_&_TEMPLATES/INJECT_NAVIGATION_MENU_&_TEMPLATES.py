#!/usr/bin/env python3
"""Fixed submission-only navigation injection. Validates and backs up before writing."""
from __future__ import annotations
import datetime as dt
import os
import re
import shutil
import sys
from pathlib import Path

def windows_path(path: Path) -> Path:
    """Use Unicode Windows extended paths for deep source and backup trees."""
    path = path.resolve()
    if os.name != 'nt' or str(path).startswith('\\\\?\\'):
        return path
    value = str(path)
    if value.startswith('\\\\'):
        return Path('\\\\?\\UNC\\' + value[2:])
    return Path('\\\\?\\' + value)


SCRIPT = windows_path(Path(__file__))
TOOL_DIR = SCRIPT.parent
APPENDIX = TOOL_DIR.parents[2]  # A.P.X._CODES -> RP9._A.P.X._SYSTEM -> appendix
ROOT = APPENDIX.parent  # Submission root containing A-D and the appendix
READING_ORDER = TOOL_DIR / 'A. RP9. THE RIEMANN SUBMISSION READING ORDER' / '05. RP9. COMPLETE RECOMMENDED READING ORDER.md'
TEMPLATE = TOOL_DIR / 'A. SUBMISSION NAVIGATION - MENY TEMPLATE' / 'A. SUBMISSION NAVIGATION - MENY TEMPLATE.md'
START = '<!-- RP9_NAVIGATION_BEGIN:{kind} -->'
END = '<!-- RP9_NAVIGATION_END:{kind} -->'
LINK = re.compile(r'\[\[([^\]|#]+)(?:\|[^\]]*)?\]\]')
NUMBERED = re.compile(r'(?m)^\s*>?\s*[├└│─ ]*\s*(\d{2})\.\s*🔗\s*')


def comparable_name(name: str) -> str:
    # Downloaded attachments may carry a copy number or timestamp before .md.
    stem = re.sub(r'(?:\.md)+$', '', name, flags=re.I).strip()
    stem = re.sub(r'\s*\((?:\d+|\d{8}-\d{6})\)$', '', stem).strip()
    stem = re.sub(r'\s*&\s*LINKED$', '', stem, flags=re.I)
    return re.sub(r'[^a-z0-9]+', '', stem.casefold())


def locate_input(expected: Path) -> Path:
    """Prefer the declared path; otherwise find one matching file inside this tool."""
    if expected.is_file():
        return expected
    matches = []
    wanted = comparable_name(expected.name)
    search_root = ROOT if wanted.startswith('05rp9completerecommendedreadingorder') else TOOL_DIR
    for current, directories, filenames in os.walk(search_root):
        directories[:] = [name for name in directories
                          if name not in {'NAVIGATION_BACKUPS', 'GENERATED'}
                          and not name.startswith('.')
                          and not (Path(current) / name).is_symlink()]
        for name in filenames:
            if name.lower().endswith('.md') and comparable_name(name) == wanted:
                candidate = Path(current) / name
                if not candidate.is_symlink():
                    matches.append(candidate)
    if len(matches) == 1:
        print(f'LOCATED: {matches[0]}')
        return matches[0]
    if len(matches) > 1:
        raise ValueError('Multiple matching input files; no documents changed:\n'
                         + '\n'.join(str(path) for path in matches))
    raise FileNotFoundError(f'Required input not found inside {search_root}: {expected.name}')


def load(path: Path) -> tuple[str, str]:
    data = path.read_bytes()
    encoding = 'utf-8-sig' if data.startswith(b'\xef\xbb\xbf') else 'utf-8'
    return data.decode(encoding), encoding


def safe_path(link: str) -> Path:
    name = link.strip().replace('\\', '/')
    if name.startswith('/') or re.match(r'^[A-Za-z]:', name) or '..' in Path(name).parts:
        raise ValueError(f'Unsafe link: {link}')
    # Source lists may include the submission folder's name, or be root-relative.
    parts = name.split('/')
    if parts and parts[0] == ROOT.name:
        parts = parts[1:]
    if not parts or not any(parts):
        raise ValueError(f'Empty document path: {link}')
    p = ROOT.joinpath(*parts)
    if not name.lower().endswith('.md'):
        p = p.with_name(p.name + '.md')
    if not p.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError(f'Link escapes root: {link}')
    return p


def wiki(path: Path, label: str) -> str:
    # Use actual vault-relative paths when the vault can be detected.
    # Otherwise preserve the submission-prefixed convention of the source list.
    vault = next((candidate for candidate in (ROOT, *ROOT.parents)
                  if (candidate / '.obsidian').is_dir()), ROOT.parent)
    relative = path.relative_to(vault).as_posix()
    if relative.lower().endswith('.md'):
        relative = relative[:-3]
    return f'[[{relative}|{label}]]'


def collect() -> list[Path]:
    content, _ = load(READING_ORDER)
    matches, numbers = [], []
    # Read only numbered sequence entries, never sample menus or introductory links.
    for line in content.splitlines():
        number = NUMBERED.search(line)
        if number:
            targets = LINK.findall(line)
            if len(targets) != 1:
                raise ValueError('Each numbered entry must contain exactly one document link')
            numbers.append(int(number.group(1)))
            matches.extend(targets)
    if numbers != list(range(1, 54)):
        raise ValueError('The reading order must contain entries 01 through 53 exactly once and in order')
    documents, seen = [], set()
    for link in matches:
        target = safe_path(link)
        if target.suffix.lower() != '.md':
            raise ValueError(f'Non-Markdown target in reading order: {link}')
        if target.resolve() == READING_ORDER.resolve() or APPENDIX.resolve() in target.resolve().parents:
            raise ValueError(f'Submission target must be outside the appendix: {link}')
        if target.resolve() in seen:
            raise ValueError(f'Duplicate submission document: {link}')
        if not target.is_file():
            raise FileNotFoundError(f'Listed Markdown target does not exist: {target}')
        seen.add(target.resolve())
        documents.append(target)
    return documents


def render(template: str, prev: Path | None, nxt: Path | None) -> str:
    for token in ('{{NEXT_LINK}}', '{{PREVIOUS_LINK}}'):
        if template.count(token) != 1:
            raise ValueError(f'Template must contain exactly one {token}')
    if '{{HOME_LINK}}' in template:
        raise ValueError('The submission template must contain a fixed HOME link')
    # The fixed HOME link is validated but is never changed by this program.
    fixed_links = LINK.findall(template)
    if len(fixed_links) != 1:
        raise ValueError('Submission template must contain exactly one fixed HOME link')
    fixed_home = fixed_links[0]
    if comparable_name(Path(fixed_home.replace('\\', '/')).name) != comparable_name(READING_ORDER.name):
        raise ValueError('The fixed HOME link must identify the submission reading order')
    actual_home = wiki(READING_ORDER, 'HOME').split('|', 1)[0][2:]
    if safe_path(fixed_home).resolve() != READING_ORDER.resolve():
        # Retain the label and all template formatting; repair only its stale target.
        template = template.replace('[[' + fixed_home, '[[' + actual_home, 1)
    values = {
        '{{NEXT_LINK}}': wiki(nxt, 'NEXT Recommended Document') if nxt else wiki(READING_ORDER, 'NEXT — Return to Index'),
        '{{PREVIOUS_LINK}}': wiki(prev, 'PREVIOUS Recommended Document') if prev else wiki(READING_ORDER, 'PREVIOUS — Return to Index'),
    }
    for token, value in values.items():
        template = template.replace(token, value)
    return f'{START.format(kind="A")}\n{template.strip()}\n{END.format(kind="A")}'


def prepare(original: str, kind: str, block: str, allow_existing: bool) -> tuple[str, str]:
    newline = '\r\n' if '\r\n' in original else '\n'
    block = block.replace('\r\n', '\n').replace('\n', newline)
    start, end = START.format(kind=kind), END.format(kind=kind)
    if (start in original) != (end in original):
        raise ValueError('Incomplete managed navigation markers')
    if start in original:
        if original.count(start) != 1 or original.count(end) != 1:
            raise ValueError('Duplicate managed navigation markers')
        begin = original.index(start)
        end_at = original.index(end)
        if end_at < begin:
            raise ValueError('Managed navigation markers are in the wrong order')
        finish = end_at + len(end)
        changed = original[:begin] + block + original[finish:]
        return changed, 'UPDATE'
    # Do not silently stack a second menu over a legacy one.
    if not allow_existing and re.search(r'\[!(?:rp9-black|DANGER)\]', original, re.I) and re.search(r'NEXT\s*▶|◀\s*PREVIOUS', original, re.I):
        raise ValueError('Unmanaged navigation menu detected; review manually or use --allow-existing')
    newline = '\r\n' if '\r\n' in original else '\n'
    return original + newline * 2 + block + newline, 'INSERT'


def main() -> int:
    global READING_ORDER, TEMPLATE
    print('RP9 SUBMISSION NAVIGATION — AUTOMATIC INJECTION')
    print(f'REPOSITORY ROOT: {ROOT}')
    print(f'READING ORDER: {READING_ORDER}')
    print(f'TEMPLATE: {TEMPLATE}')
    plan = []
    try:
        READING_ORDER = locate_input(READING_ORDER)
        TEMPLATE = locate_input(TEMPLATE)
        documents = collect()
        template, _ = load(TEMPLATE)
        for i, path in enumerate(documents):
            original, encoding = load(path)
            block = render(template, documents[i-1] if i else None,
                           documents[i+1] if i+1 < len(documents) else None)
            updated, action = prepare(original, 'A', block, False)
            if updated != original:
                plan.append((path, original, updated, encoding))
            print(f'{i+1:02d}/53 {action if updated != original else "UNCHANGED"}: {path.relative_to(ROOT)}')
    except (OSError, UnicodeError, ValueError) as error:
        print(f'ABORTED BEFORE WRITING: {error}', file=sys.stderr)
        return 1
    print(f'VALIDATED: 53 documents. PLANNED CHANGES: {len(plan)}')
    if not plan:
        print('COMPLETE: All navigation blocks are already up to date.')
        return 0
    backup = TOOL_DIR / 'NAVIGATION_BACKUPS' / dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    # Finish all backups before writing to any document.
    try:
        for path, *_ in plan:
            destination = backup / path.relative_to(ROOT)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
        for path, original, updated, encoding in plan:
            temporary = path.with_name(path.name + '.rp9_nav_tmp')
            temporary.write_bytes(updated.encode(encoding))
            temporary.replace(path)
    except OSError as error:
        print(f'WRITE FAILED: {error}. Originals backed up under {backup}', file=sys.stderr)
        return 2
    print(f'COMPLETE: {len(plan)} documents updated. BACKUPS: {backup}')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\nInterrupted.")
        raise SystemExit(1)
