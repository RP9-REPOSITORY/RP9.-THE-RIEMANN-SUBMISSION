@echo off
setlocal EnableExtensions
if "%RP9_NAV_WINDOW%"=="1" goto MAIN
set "RP9_NAV_WINDOW=1"
start "RP9 Submission Navigation" cmd.exe /d /k ""%~f0""
exit /b

:MAIN
cd /d "%~dp0"
set "SCRIPT=%~dp0A.P.X._CODES\5._NAVIGATION_MENU_&_TEMPLATES\INJECT_NAVIGATION_MENU_&_TEMPLATES.py"
echo RP9 SUBMISSION NAVIGATION - AUTOMATIC INJECTION
echo.
if not exist "%SCRIPT%" goto NO_SCRIPT
py -3 -c "import sys; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 goto USE_PY
python -c "import sys; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON
echo ERROR: No working Python 3.9 or newer was found.
exit /b 1
:USE_PY
py -3 "%SCRIPT%"
goto RESULT
:USE_PYTHON
python "%SCRIPT%"
goto RESULT
:RESULT
set "RP9_RESULT=%ERRORLEVEL%"
echo.
echo Python exit code: %RP9_RESULT%
echo The CMD window remains open for inspection.
exit /b %RP9_RESULT%
:NO_SCRIPT
echo ERROR: Python script not found:
echo "%SCRIPT%"
exit /b 1
