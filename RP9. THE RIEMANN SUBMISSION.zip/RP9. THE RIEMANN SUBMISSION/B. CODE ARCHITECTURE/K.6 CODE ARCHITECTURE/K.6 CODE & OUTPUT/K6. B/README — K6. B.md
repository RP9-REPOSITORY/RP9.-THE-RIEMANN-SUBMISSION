
## DOCUMENT OVERVIEW

*This README describes the K6. B Binary Pulse remainder control, its exact arithmetic, execution domain, output behaviour, recorded results, and examination method.*

---

## 1. PROGRAM IDENTITY AND FUNCTION

| Field | Value |
| --- | --- |
| Python Code ID | **K6. B** |
| RP9 Code ID | **C.0086** |
| Official code title | **K6. EXACT BINARY PULSE INVARIANCE CHECK** |
| Source | `1. Python/K6. B.py` |
| Version | `3.0.0` |
| Control ID | `K6_BINARY_PULSE_T01` |
| Author | Anton Wallin |

For each position $n$, the program calculates:

$$
q_n=\frac{3/4}{2^n},
\qquad
c_n=\frac8{q_n},
$$

then separates the integer whole part and fractional remainder:

$$
w_n=\lfloor c_n\rfloor,
\qquad
r_n=c_n-w_n.
$$

The symbols $c_n$, $w_n$, and $r_n$ describe the source variables `quotient`, `whole_part`, and `remainder`.

The control compares each observed remainder with its parity-dependent expectation. It requires no output from another K.6, K.7, or K.8 program.

---

## 2. INPUT DEFINITIONS

| Source constant | Value | Assigned role |
| --- | --- | --- |
| `POSITION_COUNT` | $100$ | Number of evaluated positions |
| `PULSE_BASE` | $\frac34$ | Initial binary-halving value |
| `CONTROL_VALUE` | $8$ | Numerator of the control quotient |
| `EVEN_REMAINDER` | $\frac23$ | Expected remainder at even positions |
| `ODD_REMAINDER` | $\frac13$ | Expected remainder at odd positions |

A position is the integer index $n$ in $2^n$. The implemented range is $0$–$99$.

Binary Pulse identifies successive halving:

$$
q_{n+1}=\frac{q_n}{2}.
$$

The implementation calculates each value directly using `PULSE_BASE / (2 ** position)`.

The whole part is obtained by integer floor division of the quotient's numerator by its denominator. Subtracting it produces the exact fractional remainder:

$$
0\leq r_n<1.
$$

Binary Pulse invariance means preservation of the defined alternating remainder pattern across the evaluated binary scales.

---

## 3. ARITHMETIC AND CONTROL CONDITIONS

Calculations use `fractions.Fraction` and integer operations. No floating-point value or tolerance participates in `PASS` or `FAIL`.

The expected remainder is:

$$
e_n=
\begin{cases}
\frac23, & n\ \text{even},\\
\frac13, & n\ \text{odd}.
\end{cases}
$$

| Level | PASS condition |
| --- | --- |
| Individual position | $r_n=e_n$ exactly |
| Complete execution | No positional failures |

The one control, `K6_BINARY_PULSE_T01`, is evaluated at one hundred positions. The one hundred positional results are not separate control definitions.

`first_deviation` identifies the first failing position. With no failures, it is `null` in JSON and `NONE` in the report and control log.

Serialised rational values contain `fraction`, `numerator`, and `denominator`. Integer whole parts are recorded separately.

---

## 4. INITIAL POSITION EXAMPLES

| Position $n$ | Pulse $q_n$ | Quotient $8/q_n$ | Whole part | Expected remainder | Observed remainder |
| --- | --- | --- | --- | --- | --- |
| $0$ | $\frac34$ | $\frac{32}{3}$ | $10$ | $\frac23$ | $\frac23$ |
| $1$ | $\frac38$ | $\frac{64}{3}$ | $21$ | $\frac13$ | $\frac13$ |
| $2$ | $\frac3{16}$ | $\frac{128}{3}$ | $42$ | $\frac23$ | $\frac23$ |
| $3$ | $\frac3{32}$ | $\frac{256}{3}$ | $85$ | $\frac13$ | $\frac13$ |

The JSON data and Markdown report contain all one hundred positional records.

---

## 5. EXECUTION

Python 3 and the standard-library modules imported by the script are required.

No third-party packages, external datasets, network access, or command-line parameters are required. The output directory must be writable.

From the **K6. B** package root, run:

```bash
python "1. Python/K6. B.py"
```

If the Python executable is named `python3`, use:

```bash
python3 "1. Python/K6. B.py"
```

The output location is resolved from the script's own path, independently of the terminal's working directory.

On Windows, with interactive terminal input, the script waits for Enter before closing.

---

## 6. EXECUTION AND OUTPUT BEHAVIOUR

The implemented sequence is:

1. `execute_control()` calculates pulse values, quotients, whole parts, and remainders.
2. `expected_remainder()` selects each expectation from positional parity.
3. `execute_control()` records statuses, totals, first deviation, and global status.
4. `write_outputs()` writes three files, using `build_markdown()` for the report.
5. `main()` prints the summary and actual output directory, then returns the exit code.

The output directory is defined as:

```python
Path(__file__).resolve().parent / "2. OUTPUT"
```

With the source in `1. Python/K6. B.py`, a new run writes to:

**`1. Python/2. OUTPUT/`**

The supplied records are stored separately in **`2. OUTPUT/`**, with a report copy in **`3. FINAL REPORTS/`**.

The script does not automatically transfer new outputs to those package-level folders. Repeated execution overwrites the three named files in the actual output directory.

---

## 7. OUTPUT FILES

| File | Function |
| --- | --- |
| `K6.B_DATA.json` | Identity, version, timestamp, arithmetic, domain, constants, positional records, and aggregate result |
| `K6.B_REPORT.md` | Function description, validation domain, complete positional table, and final result |
| `K6.B_CONTROL.log` | Code and control identity, version, timestamp, range, counts, first deviation, and global status |

Each JSON positional record contains:

- `position`;
- `q_n`;
- `control_8_div_q_n`;
- `whole_part`;
- `observed_remainder`;
- `expected_remainder`;
- `status`.

The supplied reports in `2. OUTPUT/` and `3. FINAL REPORTS/` have identical SHA-256 checksums and represent copies of the same recorded report.

The actual output directory is printed to the terminal. The control log contains no output-directory field.

---

## 8. RECORDED RESULT

The supplied outputs:

| Field | Recorded value |
| --- | --- |
| Control ID | `K6_BINARY_PULSE_T01` |
| First position | $0$ |
| Last position | $99$ |
| Position count | $100$ |
| PASS | $100$ |
| FAIL | $0$ |
| First deviation | `NONE` |
| Global status | `PASS` |

Global `PASS` means that every executed position produced its exact expected remainder.

---

## 9. EXIT CODES

| Code | Meaning |
| --- | --- |
| `0` | All positions pass and output writing completes successfully |
| `1` | Output writing completes, but at least one position fails |
| `2` | An execution exception occurs and a traceback is printed to standard error |

An exception during output writing may leave an incomplete output set. Assess execution using both the exit code and the generated records.

---

## 10. EXAMINATION AND TRACEABILITY

1. Inspect the source constants, range, quotient calculation, remainder extraction, and parity expectations.
2. Check the JSON domain and definitions.
3. Trace each position through its pulse value, quotient, whole part, observed remainder, expectation, and status.
4. Compare JSON totals and first deviation with the control log and Markdown report.
5. For a reproduced run, inspect the output directory printed by the script.

Use the control ID to identify the operation and the position index to identify its individual evaluation.

The Python source defines the operations; the output files record their execution.




<!-- RP9_NAVIGATION_BEGIN:A -->

---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>---
>
>#### <center><code>$\boxed{\text{ASCII ARCHITECTURE}}$</code></center>
>---
>```ASCII
> 📁 RP9. THE RIEMANN SUBMISSION
> └─ 📁 B. CODE ARCHITECTURE
>     └─ 📂 K.6 CODE ARCHITECTURE
>         └─ 📂 K.6 CODE & OUTPUT
>             └─ 📂 K6. B
>                 └─ README — K6. B
> ```  
>---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 [[B. CODE ARCHITECTURE/K.6 CODE ARCHITECTURE/K.6 CODE & OUTPUT/K6. B/1. Python/K6. B. PYTHON|K6. B. PYTHON]]
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 [[B. CODE ARCHITECTURE/K.6 CODE ARCHITECTURE/K.6 CODE & OUTPUT/K6. A/3. FINAL REPORTS/K6.A_REPORT|K6.A_REPORT]]
> >
> > ---
> >
> > 
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  **[[RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]**
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---

<!-- RP9_NAVIGATION_END:A -->
