---
rp9:
  author: "Anton Wallin"
  package: "RP9. THE RIEMANN SUBMISSION"
  language: "en"
  within_submission:
  object_class: []
  document_id: DOC.F5331A2E7CDB7A74
  official_title: DOCUMENT OVERVIEW
  document_type: readme
  relative_path: B. CODE ARCHITECTURE/K.6 CODE ARCHITECTURE/K.6 CODE & OUTPUT/K6. A/README — K6. A.md
---

## DOCUMENT OVERVIEW

*This README describes the K6. A scale-invariance crosscheck, its exact rational controls, execution requirements, output behaviour, recorded results, and examination method.*

---

## 1. PROGRAM IDENTITY AND FUNCTION

| Field | Value |
| --- | --- |
| Python Code ID | **K6. A** |
| RP9 Code ID | **C.0084** |
| Official code title | **K6. SCALE INVARIANCE CROSSCHECK** |
| Source | `1. Python/K6. A.py` |
| Version | `2.0.0` |
| Author | Anton Wallin |

The program checks reciprocal multiplication, division by $2$, complementary addition, and equality between defined rational quotients.

Its inputs are source constants. It requires no output from another K.6, K.7, or K.8 program.

---

## 2. INPUT DEFINITIONS

| Source constant | Value | Assigned role |
| --- | --- | --- |
| `LINEAR_CONTAINED` | $\frac23$ | Contained linear relation |
| `LINEAR_EXPANDED` | $\frac32$ | Expanded linear relation |
| `PLANAR_MAIN` | $\frac34$ | Main planar relation |
| `PLANAR_COMPLEMENT` | $\frac14$ | Complementary planar relation |
| `VOLUMETRIC_MAIN` | $\frac68$ | Main volumetric representation |
| `VOLUMETRIC_COMPLEMENT` | $\frac28$ | Complementary volumetric representation |

Reciprocal closure means that the specified reciprocal values multiply to $1$. Normalisation is the implemented division of $\frac32$ by $2$. Complementary closure means that the specified parts sum to $1$. Scale invariance means exact quotient equality between the specified representations.

The linear, planar, and volumetric labels identify assigned relational roles. The implemented calculations operate on rational numbers.

---

## 3. ARITHMETIC AND SERIALISATION

All controls use `fractions.Fraction` and exact equality without floating-point tolerance.

Equivalent fractions are automatically reduced:

$$
\frac68=\frac34,
\qquad
\frac28=\frac14.
$$

Consequently, the observed JSON values for the volumetric relations appear as `3/4` and `1/4`. Their original representation labels remain in the source constants and control descriptions.

Each serialised rational value contains `fraction`, `numerator`, and `denominator`.

---

## 4. CONTROL MATRIX

| Control ID | Function | Operation | PASS condition |
| --- | --- | --- | --- |
| `K6_SCALE_T01` | Reciprocal directional lock | $\frac23\times\frac32$ | Product equals $1$ |
| `K6_SCALE_T02` | Linear-to-planar normalization | $\frac32\div2$ | Result equals $\frac34$ |
| `K6_SCALE_T03` | Planar complementary closure | $\frac34+\frac14$ | Sum equals $1$ |
| `K6_SCALE_T04` | Main relation scale invariance | $\frac34=\frac68$ | Exact quotient equality |
| `K6_SCALE_T05` | Complementary relation scale invariance | $\frac14=\frac28$ and $\frac68+\frac28=1$ | Both conditions hold |
| `K6_SCALE_T12` | Global submitted-chain control | Aggregate of `K6_SCALE_T01`–`K6_SCALE_T05` | All five substantive controls pass |

The six recorded controls comprise five substantive controls and one aggregate. The aggregate introduces no additional numerical relation.

The identifiers follow the implementation. There are no controls `T06`–`T11`.

---

## 5. EXECUTION

Python and the standard-library modules imported by the script are required. The supplied execution record identifies Python `3.11.9` on Windows.

No third-party packages, external datasets, network access, or command-line parameters are required. The output directory must be writable.

From the **K6. A** package root, run:

```bash
python "1. Python/K6. A.py"
```

If the Python executable is named `python3`, use:

```bash
python3 "1. Python/K6. A.py"
```

The script resolves the output location from its own path, independently of the terminal's working directory.

On Windows, with interactive terminal input, it waits for Enter before closing.

---

## 6. EXECUTION AND OUTPUT BEHAVIOUR

The implemented sequence is:

1. `run_crosschecks()` evaluates the five substantive controls and their aggregate.
2. `build_payload()` assembles metadata, chain definitions, control records, and total status.
3. `write_outputs()` writes five files.
4. `main()` prints results and returns the exit code.

The output directory is defined as:

```python
Path(__file__).resolve().parent / "2. OUTPUT"
```

With the source in `1. Python/K6. A.py`, a new run writes to:

**`1. Python/2. OUTPUT/`**

The supplied records are stored separately in **`2. OUTPUT/`**, with a report copy in **`3. FINAL REPORTS/`**.

The script does not automatically transfer new outputs to those package-level folders. Repeated execution overwrites the five named files in the actual output directory.

---

## 7. OUTPUT FILES

| File | Function |
| --- | --- |
| `K6.A_DATA.json` | Execution metadata, tested chain, expected and observed values, statuses, boundaries, and aggregate result |
| `K6.A_TRACE.json` | Ordered control records, step numbers, and payload creation timestamp |
| `K6.A_REPORT.md` | Human-readable function description, control matrix, scope, and result |
| `K6.A_CONTROL.txt` | Code identity, version, timestamp, control statuses, and global status |
| `K6.A_EXECUTION.log` | Code identity, version, actual output directory, file count, and global status |

The trace uses the same payload creation timestamp for every step. It records control order, not individual calculation durations.

The supplied reports in `2. OUTPUT/` and `3. FINAL REPORTS/` have identical SHA-256 checksums and represent copies of the same recorded report.

---

## 8. RECORDED RESULT

The supplied outputs:

| Field | Recorded value |
| --- | --- |
| Substantive controls | $5$ |
| Aggregate controls | $1$ |
| Total controls | $6$ |
| PASS | $6$ |
| FAIL | $0$ |
| Global status | `PASS` |

This result states that all defined reciprocal operations, normalisation, quotient comparisons, and complementary closures passed within the implemented local chain.

---

## 9. EXIT CODES

| Code | Meaning |
| --- | --- |
| `0` | Controls pass and output writing completes successfully |
| `1` | Output writing completes, but global control status is `FAIL` |
| `2` | An execution exception occurs and a traceback is printed to standard error |

An exception during output writing may leave an incomplete output set. Assess execution using both the exit code and the generated records.

---

## 10. EXAMINATION AND TRACEABILITY

1. Inspect the source constants, operations, PASS conditions, and output behaviour.
2. Check `K6.A_DATA.json` for expected values, observations, arithmetic metadata, and aggregate status.
3. Check `K6.A_TRACE.json` for exact control identifiers and ordered steps.
4. Compare the control file and Markdown report with the detailed data.
5. Use `K6.A_EXECUTION.log` to identify the recorded output directory.
6. For a reproduced run, inspect the directory actually written by the script.

Trace each result through its source constant, implemented operation, control identifier, and recorded observation.

The Python source defines the operations; the output files record their execution.




<!-- RP9_NAVIGATION_BEGIN:A -->

---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>---
>
>#### <center><code>$\boxed{\text{ASCII ARCHITECTURE}}$</code></center>
>---
>```ASCII
> 📁 RP9. THE RIEMANN SUBMISSION
> └─ 📁 B. CODE ARCHITECTURE
>     └─ 📂 K.6 CODE ARCHITECTURE
>         └─ 📂 K.6 CODE & OUTPUT
>             └─ 📂 K6. A
>                 └─ README — K6. A
> ```  
>---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 [[K6. A. PYTHON|K6. A. PYTHON]]
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 [[K6. SUBMISSION REVIEWER'S CODE GUIDE|K6. SUBMISSION REVIEWER'S CODE GUIDE]]
> >
> > ---
> >
> > 
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  **[[RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]**
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---

<!-- RP9_NAVIGATION_END:A -->
