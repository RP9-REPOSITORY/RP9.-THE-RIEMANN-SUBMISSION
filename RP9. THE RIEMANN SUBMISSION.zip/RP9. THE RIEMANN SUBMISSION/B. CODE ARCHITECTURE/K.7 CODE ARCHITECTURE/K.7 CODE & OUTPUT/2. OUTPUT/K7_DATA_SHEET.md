---
rp9:
  author: "Anton Wallin"
  package: "RP9. THE RIEMANN SUBMISSION"
  language: "en"
  within_submission:
  object_class: []
  document_id: DOC.DEE8239CA94F34F6
  official_title: P.B.F. FULL POSITIONAL GENEALOGY — DATA SHEET
  document_type: document
  relative_path: B. CODE ARCHITECTURE/K.7 CODE ARCHITECTURE/K.7 CODE & OUTPUT/2. OUTPUT/K7_DATA_SHEET.md
---
# P.B.F. FULL POSITIONAL GENEALOGY — DATA SHEET

| Limit | Observation | Closures | Reproduced | FP | FN | Exact | Status |
|---:|---:|---:|---:|---:|---:|:---:|:---:|
| 1000000 | 333334 | 78498 | 254836 | 0 | 0 | True | PASS |
| 10000000 | 3333334 | 664579 | 2668755 | 0 | 0 | True | PASS |
| 100000000 | 33333334 | 5761455 | 27571879 | 0 | 0 | True | PASS |
| 1000000000 | 333333334 | 50847534 | 282485800 | 0 | 0 | True | PASS |
| 10000000000 | 3333333334 | 455052511 | 2878280823 | 0 | 0 | True | PASS |
| 100000000000 | 33333333334 | 4118054813 | 29215278521 | 0 | 0 | True | PASS |
