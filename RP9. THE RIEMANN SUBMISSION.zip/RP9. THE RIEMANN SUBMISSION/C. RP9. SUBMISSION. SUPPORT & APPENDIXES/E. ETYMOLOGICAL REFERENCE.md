---
rp9:
  author: "Anton Wallin"
  package: "RP9. THE RIEMANN SUBMISSION"
  language: "en"
  within_submission:
  object_class: []
  document_id: DOC.A7E6FC8B284B4627
  official_title: DOCUMENT OVERVIEW
  document_type: document
  relative_path: C. RP9. SUBMISSION. SUPPORT & APPENDIXES/E. ETYMOLOGICAL REFERENCE.md
---

## DOCUMENT OVERVIEW

*This appendix provides a linguistic reference for four terms used in the RP9 Riemann Submission: Primary, Binary, Differentiation and Sequence.*

*It separates their historical origins and meanings from their functional application within P.B.F. Its role is terminological support, not independent derivation or validation.*

---

## PURPOSE AND SCOPE

This document belongs to **C. RP9. SUBMISSION. SUPPORT & APPENDIXES** within **RP9. THE RIEMANN SUBMISSION**.

Its purpose is to clarify selected terminology while preserving the distinction between function, representation and description.

Historical origins and usage are summarized from the **Online Etymology Dictionary**. The **Functional correspondence** subsections describe RP9's application of the terms; those applications are not attributed to the dictionary.

Terminology describes the relations established in the governing presentation. Etymology does not determine those relations or establish their mathematical validity.

| No. | Term            | Reference focus                     |
| --- | --------------- | ----------------------------------- |
| 01  | Primary         | First or principal position.        |
| 02  | Binary          | Twofold organization.               |
| 03  | Differentiation | Difference and distinction.         |
| 04  | Sequence        | Ordered succession.                 |
| 05  | DOWNSTREAM      | **Downstream** identifies positions |
| 06. | GENEALOGY       | Descent                             |

---

## 01. PRIMARY

**Word class:** Adjective; also noun.

### Etymological origin and historical meaning

The adjective is recorded in English from the early fifteenth century. It derives from Latin *primarius*, associated with principal rank, and ultimately from *primus*, denoting firstness.

Early English usage concerns precedence in time or order and basic status. Usage concerning rank or importance is recorded from the 1560s. The noun is recorded from 1760 for something occupying a leading position.

**Reference focus:** Firstness, precedence and principal status.

### Functional correspondence

Within P.B.F., **Primary** identifies the first or principal functional position from which subsequent differentiation is described.

It helps distinguish primary establishment from downstream operations within an already established relation. The intended precedence is defined by the derivation, rather than by the word's historical origin.

**Source:** [Primary — Online Etymology Dictionary](https://www.etymonline.com/word/primary)

---

## 02. BINARY

**Word class:** Adjective.

### Etymological origin and historical meaning

The adjective is recorded in English from the middle of the fifteenth century. It derives from Late Latin *binarius*, referring to composition in twos, through Latin *bini*, associated with pairs or distribution two at a time, and *bis*, associated with doubling.

Its historical meanings concern dual or twofold organization.

**Reference focus:** Organization involving two.

### Functional correspondence

Within P.B.F., **Binary** identifies the twofold organization of the established positions and primary functions.

The word alone does not specify equality, inequality, opposition or complementarity. Those properties follow from the particular relations and operations presented in the derivation.

**Source:** [Binary — Online Etymology Dictionary](https://www.etymonline.com/word/binary)

---

## 03. DIFFERENTIATION

**Word class:** Noun.

### Etymological origin and historical meaning

The noun is formed from *differentiate*. The verb derives through Medieval Latin *differentiatus* and *differentiare* from Latin *differentia*, associated with diversity and difference.

The dictionary records the noun in calculus in 1831, in usage concerning an action or condition of difference in 1855, and in usage concerning recognition of a difference in 1866.

These usages distinguish a technical mathematical operation from broader senses concerning the production or recognition of distinctions.

**Reference focus:** Becoming, making or recognizing something distinguishable.

### Functional correspondence

Within P.B.F., **Differentiation** concerns the establishment of distinguishable functional positions or expressions.

Primary differentiation and downstream differentiation retain their respective meanings in the governing presentation. The term does not designate calculus differentiation merely because that technical usage appears in its history.

**Source:** [Differentiation — Online Etymology Dictionary](https://www.etymonline.com/word/differentiation)

---

## 04. SEQUENCE

**Word class:** Noun; also used as a verb.

### Etymological origin and historical meaning

The noun is recorded in English from the late fourteenth century, initially in church music. It derives through Old French *sequence* and Medieval Latin *sequentia*, ultimately from Latin *sequi*, associated with following.

General usage for an ordered succession is recorded by the 1570s, with usage concerning succession order recorded by the 1580s.

**Reference focus:** Following in an identifiable order.

### Functional correspondence

Within P.B.F., **Sequence** describes the ordered progression of positions or operations in the presented construction and computational material.

The term identifies order. The applicable definitions and operations specify what generates the sequence, how its transitions occur and what continuation is permitted.

**Source:** [Sequence — Online Etymology Dictionary](https://www.etymonline.com/word/sequence)

---
## 05. DOWNSTREAM

**Word class:** Adverb; also adjective.

### Etymological origin and historical meaning

The adverb is recorded in English from 1706, formed from the phrase *down stream*, combining *down* and *stream*.

Its historical meaning concerns movement with, or in the direction of, a stream's current. Adjectival usage is recorded by 1842.

**Reference focus:** Direction along a flow, toward a subsequent position.

### Functional correspondence

Within P.B.F., **Downstream** identifies positions, operations or representations that follow from already established functional relations.

It distinguishes primary establishment from subsequent differentiation and development within the defined construction.

The direction concerns functional dependency and establishment order. Its specific meaning is supplied by the governing presentation.

**Source:** [Downstream — Online Etymology Dictionary](https://www.etymonline.com/word/downstream)

---

## 06. GENEALOGY

**Word class:** Noun.

### Etymological origin and historical meaning

The noun is recorded in English from the early fourteenth century, through Old French *genealogie* and Late Latin *genealogia*, from Greek *genealogia*.

The Greek formation combines *genea*, associated with generation and descent, with *-logia*.

Historical usage concerns a line of descent or the tracing of ancestry. Usage concerning the study of family trees is recorded from 1768.

**Reference focus:** Descent, successive generations and traceable ancestry.

### Related form: Genealogical

**Genealogical** is an adjective recorded from the 1570s, derived through French *généalogique*.

It describes something pertaining to genealogy or exhibiting successive descent from an originating ancestor.

### Functional correspondence

Within P.B.F. and **K7. FULL POSITIONAL GENEALOGY**, **Genealogy** describes the generative lineage of positions through the defined sequential operation.

**Genealogical** describes the continuity of that lineage, including the preservation of generated state and active references across consecutive segments.

The application concerns computational generation and positional continuity. The governing source code defines the actual operations and dependencies; the linguistic origin does not establish their correctness.

**Sources:**

- [Genealogy — Online Etymology Dictionary](https://www.etymonline.com/word/genealogy)
- [Genealogical — Online Etymology Dictionary](https://www.etymonline.com/word/genealogical)



---

## 07. CONSOLIDATED REFERENCE

| Term            | Historical reference focus                    | P.B.F. functional correspondence                                                        |
| --------------- | --------------------------------------------- | --------------------------------------------------------------------------------------- |
| Primary         | First or principal status.                    | Primary establishment and its distinction from downstream operations.                   |
| Binary          | Twofold organization.                         | Two established positions or primary functions.                                         |
| Differentiation | Difference and distinction.                   | Establishment of distinguishable functional positions or expressions.                   |
| Sequence        | Ordered succession.                           | Progression through defined positions or operations.                                    |
| Downstream      | Direction along a stream's flow.              | Subsequent positions, operations or representations dependent on established relations. |
| Genealogy       | Descent, successive generations and ancestry. | Generative lineage and positional continuity through the defined sequential operation.  |
This table compares linguistic meanings with RP9's stated usage. Its order does not establish a derivational chain or imply a common linguistic origin.

---

## 08. SOURCE BASIS

**Reference work:** Online Etymology Dictionary.

**Author of the referenced entries:** Douglas Harper.

The four entry links above identify the sources for the historical summaries. Dates refer to recorded usage reported by the dictionary, rather than an established moment of word creation.

The functional correspondences are explanatory applications within RP9. Governing definitions, operations and validation boundaries remain in their respective submission documents.

---

## 9. DOCUMENT IDENTITY

**Title:** E. ETYMOLOGICAL REFERENCE.

**Location:** C. RP9. SUBMISSION. SUPPORT & APPENDIXES.

**Document type:** Terminological and etymological appendix.

**Scope:** Four selected English terms.

**Function:** Historical terminology reference and clarification of RP9 usage.

**Functional status:** Conceptual support; not an independent derivation or validation.



<!-- RP9_NAVIGATION_BEGIN:A -->

---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>---
>
>#### <center><code>$\boxed{\text{ASCII ARCHITECTURE}}$</code></center>
>---
>```ASCII
> 📁 RP9. THE RIEMANN SUBMISSION
> └─ 📁 C. RP9. SUBMISSION. SUPPORT & APPENDIXES
>     └─ E. ETYMOLOGICAL REFERENCE
> ```  
>---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 [[README — D. RP9. SUBMISSION. FINAL REVIEW|README — D. RP9. SUBMISSION. FINAL REVIEW]]
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 [[D. QUESTIONS AND ANSWERS|D. QUESTIONS AND ANSWERS]]
> >
> > ---
> >
> > 
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  **[[RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]**
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---

<!-- RP9_NAVIGATION_END:A -->
