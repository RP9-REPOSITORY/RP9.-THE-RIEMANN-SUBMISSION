
# README — RP9. INFORMATION & APPENDIX

---
>---
>## $\boxed{\text{ⓘ.\ LINKBORD — 🔗}}$
>---
---

> [!rp9-02] $\boxed{\text{ⓘ. Non-submission Appendix 🔗}}$
> 
>  #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>   ### $$\boxed{\text{📂— ⓘ. Non-submission Appendix}}$$
>---
>```ASCII
>     📂RP9. THE RIEMANN SUBMISSION
>      │ 
>      └─ 📂 ⓘ. Non-submission Appendix
>          │ 
>          └─ 📂 RP9. INFORMATION & APPENDIX
> ```
>---
>>
>>  $\boxed{\text{NEXT ▶}}$
>> >🔗 [[01. COPYRIGHT AND RIGHTS NOTICE|01. COPYRIGHT AND RIGHTS NOTICE]]
> 
> ---
> 
>>  $\boxed{\text{NEXT ▶}}$
>> >🔗 [[02. RP9. THE RIEMANN SUBMISSION — OFFICIAL LINKS|02. RP9. THE RIEMANN SUBMISSION — OFFICIAL LINKS]]
> ---
>>
>> $\boxed{\text{⌂ HOME ⌂}}$
>>  
>> 🔗 **[[RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]**
>---
> ### <center><code>$\boxed{\text{ END OF DOCUMENT }}$</code></center>
>---

---
