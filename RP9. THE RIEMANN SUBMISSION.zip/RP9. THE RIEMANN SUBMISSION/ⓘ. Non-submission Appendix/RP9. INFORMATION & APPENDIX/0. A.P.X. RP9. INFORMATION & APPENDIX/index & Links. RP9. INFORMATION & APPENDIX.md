> [!abstract] **RP9** 🜁 — **index & Links** 🔗
>
>> 
>
> ---
> 
> ### **📂 — RP9. INFORMATION & APPENDIX**
> 
>> ###### **🜁 — Links 🔗**
>> 
> ---
> 
> #### 📂 INDEX-X
>
>> - ###### 🔗**[[index — RP9. EXPANSION. Demo|index — RP9. EXPANSION. Demo]]**
>> - ###### 🔗**[[index — RP9. THE FORMATION OF STRUCTUR. DEMO|index — RP9. THE FORMATION OF STRUCTUR. DEMO]]**
>
>---
>
> #### 📂 RP9. INFORMATION & APPENDIX
>
>> - ###### 🔗**[[0. README — RP9. INFORMATION & APPENDIX|0. README — RP9. INFORMATION & APPENDIX]]**
>> - ###### 🔗**[[RP9. EXPANSION. Demo/01. COPYRIGHT AND RIGHTS NOTICE|01. COPYRIGHT AND RIGHTS NOTICE]]**
>> - ###### 🔗**[[INDEX-X/02. RP9. THE RIEMANN SUBMISSION — OFFICIAL LINKS|02. RP9. THE RIEMANN SUBMISSION — OFFICIAL LINKS]]**
>> - ###### 🔗**[[03. HIDDEN AND ZIPPED — MATERIAL|03. HIDDEN AND ZIPPED — MATERIAL]]**
>
>---
>
> #### 📂 0. A.P.X. RP9. INFORMATION & APPENDIX
>
>> - ###### 🔗**[[index & Links. RP9. INFORMATION & APPENDIX|index & Links. RP9. INFORMATION & APPENDIX]]**
>> - ###### 🔗**[[M.R.F. RP9. INFORMATION & APPENDIX|M.R.F. RP9. INFORMATION & APPENDIX]]**
>
>---
