# README — K8. C

---

## DOCUMENT OVERVIEW

*This package checks finite Base-10 projection and exact reconstruction of defined rational states across binary-scale levels.*

*It constructs the half, active, lock and one-eighth families and their full frame before decimal encoding.*

*Controls test exact reconstruction, expected values, complementary closure and decimal representation identity across all tested levels.*

*This **README** explains the local mechanism, execution requirements, evidence and recorded results.*

---

## 1. PACKAGE IDENTITY AND STRUCTURE

| Item | Identification |
|---|---|
| Python code ID | `K8. C` |
| RP9 code ID | `C.0097` |
| Official code title | **K8. P.B.F. BINARY STRUCTURE → BASE 10 PROJECTION LOCK VALIDATOR** |
| Source file | `1. Python/K8. C.py` |
| Program version | `2.0.0` |
| Author | Anton Wallin |

The local package is **K8. C**.

| Local location             | Function                                        |
| -------------------------- | ----------------------------------------------- |
| `README — K8. C.md`        | Package explanation and execution instructions. |
| `1. Python`                | Executable source.                              |
| `2. OUTPUT`                | Supplied execution records.                     |
| `3. FINAL REPORTS`         | Supplied final report copy.                     |

---

## 2. LOCAL FUNCTION AND DEFINITIONS

The implemented direction is:

**Binary scale expansion → exact rational state → Base-10 encoding → exact rational reconstruction → identity comparison.**

The binary factor is:

$$
f_n=2^n.
$$

The expanded source families are:

$$
H_n=\frac{2^n}{2\cdot2^n},
\qquad
A_n=\frac{3\cdot2^n}{4\cdot2^n},
\qquad
Q_n=\frac{2^n}{4\cdot2^n},
\qquad
E_n=\frac{2^n}{8\cdot2^n}.
$$

They represent the half, active, lock and one-eighth families.

The full frame is calculated from the exact source states:

$$
F_n=A_n+Q_n=1.
$$

No output from another K.6, K.7 or K.8 script is required.

| Term | Implemented meaning |
|---|---|
| Level | Integer index $n$ controlling the factor $2^n$. |
| Expanded source expression | Unreduced numerator–denominator representation retained in the output. |
| Exact source state | Reduced `Fraction` constructed before decimal encoding. |
| Half | Source state $\frac12$. |
| Active | Source state $\frac34$. |
| Lock | Complementary source state $\frac14$. |
| One eighth | Source state $\frac18$. |
| Full frame | Exact sum of active and lock states. |
| Base-10 projection | Finite decimal string encoding an already constructed rational value. |
| Reconstruction | Conversion of the decimal string into an exact `Fraction`. |
| Exact roundtrip | Reconstructed value equals its source value. |
| Cross-level identity | Each state's decimal string is identical across the tested levels. |
| Projection lock | Combined PASS of all level and cross-level checks. |

The source defines `LEVEL_COUNT = 8`. Levels $0$ through $7$ use factors $1$ through $128$.

**Lock** names the $\frac14$ source family. **Projection lock** names the overall validation result.

---

## 3. SOURCE CONSTRUCTION AND ORDER

`expanded_fraction()` multiplies a base numerator and denominator by $2^n$.

`build_level()` constructs all four exact fraction families and their full frame for one level.

In `main()`, the complete `source_levels` list is built before the projection-result list. Source construction therefore precedes Base-10 encoding.

Decimal strings are not inputs to `build_level()`.

Equivalent expanded expressions reduce to the same rational state:

$$
\frac34=\frac68=\frac{12}{16}.
$$

Expanded expressions remain recorded separately from their reduced source values.

---

## 4. EXACT DECIMAL ENCODING

`fraction_to_decimal_exact()` converts an exact `Fraction` into a finite decimal string using integer arithmetic.

It removes factors $2$ and $5$ from the reduced denominator. If another factor remains, it raises `ValueError` because a finite exact decimal representation is unavailable.

The tested states have reduced denominators $2$, $4$, $8$ and $1$, permitting terminating decimal expansions.

The encoder obtains the integer part and remainder, then generates digits through repeated multiplication of the remainder by $10$, integer division and remainder update.

| State | Exact source value | Encoded string |
|---|---|---|
| Half | $\frac12$ | `0.5` |
| Active | $\frac34$ | `0.75` |
| Lock | $\frac14$ | `0.25` |
| One eighth | $\frac18$ | `0.125` |
| Full frame | $1$ | `1` |

No floating-point arithmetic or rounding tolerance is used.

---

## 5. EXACT RECONSTRUCTION

`decimal_exact_to_fraction()` reconstructs decimal text using integer digits and a power-of-ten denominator.

For a fractional part containing $m$ digits, the denominator is $10^m$. The resulting `Fraction` is reduced exactly.

For example:

$$
0.125
\longrightarrow
\frac{125}{1000}
=
\frac18.
$$

Each state's projection record contains:

- `source_fraction`;
- `base10`;
- `reconstructed_fraction`;
- `roundtrip_exact`.

The decimal text represents the previously constructed value. Reconstruction checks whether that value is preserved.

---

## 6. LEVEL CONTROL MATRIX

`project_and_validate()` evaluates five conditions at each level.

| Check key | PASS condition |
|---|---|
| `complement_exact` | Active plus lock equals the source full frame and $1$. |
| `relational_identity_preserved` | All five source states equal their defined expected rational values. |
| `all_roundtrips_exact` | Every reconstructed state equals its source. |
| `no_new_state_introduced` | Decoding each decimal representation returns its corresponding source state. |
| `base10_expected_values_exact` | All five decimal strings match their specified expected strings. |

A level receives PASS only when all five conditions hold.

`no_new_state_introduced` repeats source equality through reconstruction. Its local meaning is that encoding introduces no different rational value.

The complement check operates on exact source fractions. Reconstruction checks separately establish that the projected components return to those values.

---

## 7. CROSS-LEVEL CONTROL

`validate_cross_level_identity()` uses the first level's decimal strings as references and compares every tested level with them.

It evaluates five state-specific checks:

- `half`;
- `active`;
- `lock`;
- `eighth`;
- `full_frame`.

Cross-level PASS requires all five checks to be true.

Global PASS requires every level and the cross-level comparison to PASS.

Source-before-projection order is established by the execution flow. It is not an additional Boolean comparison key.

---

## 8. EXECUTED SOURCE TABLE

| Level | Binary factor | Half | Active | Lock | One eighth | Status |
|---:|---:|---|---|---|---|:---:|
| $0$ | $1$ | $1/2$ | $3/4$ | $1/4$ | $1/8$ | PASS |
| $1$ | $2$ | $2/4$ | $6/8$ | $2/8$ | $2/16$ | PASS |
| $2$ | $4$ | $4/8$ | $12/16$ | $4/16$ | $4/32$ | PASS |
| $3$ | $8$ | $8/16$ | $24/32$ | $8/32$ | $8/64$ | PASS |
| $4$ | $16$ | $16/32$ | $48/64$ | $16/64$ | $16/128$ | PASS |
| $5$ | $32$ | $32/64$ | $96/128$ | $32/128$ | $32/256$ | PASS |
| $6$ | $64$ | $64/128$ | $192/256$ | $64/256$ | $64/512$ | PASS |
| $7$ | $128$ | $128/256$ | $384/512$ | $128/512$ | $128/1024$ | PASS |

Across all levels, the corresponding decimal strings remain `0.5`, `0.75`, `0.25` and `0.125`. The full frame projects to `1`.

---

## 9. EXECUTION REQUIREMENTS AND COMMAND

Use Python 3 with the standard-library modules imported by the source.

No third-party packages, external datasets, network access or command-line parameters are required.

`LEVEL_COUNT` determines the number of levels. There is no command-line option for changing it.

Write access to the output directory is required.

From the local **K8. C** package root, run:

```bash
python "1. Python/K8. C.py"
```

Where the executable is named `python3`, run:

```bash
python3 "1. Python/K8. C.py"
```

There is no interactive pause before exit.

---

## 10. EXECUTION AND OUTPUT LOCATION

The program:

1. Captures the timestamp and creates the output directory.
2. Constructs all exact source levels.
3. Encodes and reconstructs the five states at each level.
4. Evaluates level conditions.
5. Compares decimal strings across levels.
6. Determines global projection-lock status.
7. Writes three output files and prints the results.

The output directory is resolved beside the script:

```python
root = base_dir()
output_dir = root / OUTPUT_DIR_NAME
```

With the source at `1. Python/K8. C.py`, a new run writes to:

`1. Python/2. OUTPUT/`

The supplied records are stored in `2. OUTPUT/`, with a report copy in `3. FINAL REPORTS/`.

The script does not automatically transfer newly generated files to those package-level folders.

The output location is independent of the terminal's working directory. Its resolved path is recorded in `output_directory` and printed to the terminal.

Repeated execution overwrites the three named files.

---

## 11. OUTPUT FILES

| Filename | Function |
|---|---|
| `K8.C_DATA.json` | Identity, version, timestamp, execution paths, level count, expanded sources, encoded and reconstructed states, level checks, cross-level checks and global status. |
| `K8.C_REPORT.md` | Projection tables, reconstruction examples, cross-level result and projection-lock scope. |
| `K8.C_CONTROL.txt` | Identity, timestamp, level PASS count, cross-level status, target representations and final lock. |

The JSON contains detailed state and check records for every level.

The report's exact projection and reconstruction table displays the first level. Full records for all levels are retained in the JSON.

The supplied report copies in `2. OUTPUT` and `3. FINAL REPORTS` have the same SHA-256 checksum.

The script generates no separate trace file, execution log, checkpoint or error log.

---

## 12. RECORDED RESULT

| Execution field          | Recorded value      |
| ------------------------ | ------------------- |
| Program version          | `2.0.0`             |
| Levels tested            | $8$                 |
| Level range              | $0$ through $7$     |
| Level PASS               | $8$                 |
| Level FAIL               | $0$                 |
| Exact state roundtrips   | $40$ out of $40$    |
| Cross-level state checks | $5$ out of $5$ PASS |
| Cross-level identity     | PASS                |
| Base-10 projection lock  | PASS                |
| Global status            | PASS                |

Global PASS means that every defined level condition and cross-level decimal identity condition passed.

---

## 13. EXIT STATUS AND ERRORS

| Exit code | Meaning |
|---|---|
| `0` | Output writing completes and global projection-lock status is PASS. |
| `1` | Output writing completes and at least one level or cross-level condition fails. |

The script has no custom exception handler. Runtime exceptions terminate through Python's normal error handling.

The encoder raises `ValueError` for a rational state requiring a non-terminating decimal expansion.

An interrupted output write may leave an incomplete file set. Assess completion using the exit status and generated records.

---

## 14. LOCAL INSPECTION AND REPRODUCTION

1. Inspect `1. Python/K8. C.py` for source fractions, level count and construction order.
2. Trace `build_level()` to confirm that exact source states precede projection.
3. Inspect the finite-decimal encoder and exact reconstruction function.
4. Follow each state's source value, decimal text, reconstructed value and roundtrip result.
5. Inspect the five level conditions and five cross-level checks.
6. Compare the JSON records with the report and control summary.
7. For reproduction, inspect newly generated records in the directory actually written by the script.

Level indices, state names and check keys identify individual operations and results.

The local index and M.R.F. provide navigation and source identification. The Python source defines the operations; the output records their execution.

---

## 15. RESULT SCOPE

The supplied execution covers levels $0$ through $7$ for the defined exact rational families.

It records exact reconstruction, preserved source identities, complementary closure and identical decimal strings across equivalent binary-scale representations.

Base 10 functions as a downstream representation layer.

The local meaning of **no new state** is exact rational equality before encoding and after reconstruction.

---
## VALIDATION BOUNDARY

This validator checks exact value preservation between the defined relational source states and their Base-10 representations across the tested binary scales.

Base 10 is applied downstream of source-state construction. Encoding and reconstruction preserve the source values exactly.

Further states generated through continued operations on the source structure remain downstream of that structure. This validator checks the listed projection families; it does not test all such continuations.



<!-- RP9_NAVIGATION_BEGIN:A -->

---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>---
>
>#### <center><code>$\boxed{\text{ASCII ARCHITECTURE}}$</code></center>
>---
>```ASCII
> 📁 RP9. THE RIEMANN SUBMISSION
> └─ 📁 B. CODE ARCHITECTURE
>     └─ 📂 K.8 CODE ARCHITECTURE
>         └─ 📂 K.8 CODE & OUTPUT
>             └─ 📂 K8. C
>                 └─ README — K8. C
> ```  
>---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/K.8 CODE ARCHITECTURE/K.8 CODE & OUTPUT/K8. C/1. Python/K8. C. PYTHON|K8. C. PYTHON]]
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/K.8 CODE ARCHITECTURE/K.8 CODE & OUTPUT/K8. B/3. FINAL REPORTS/K8.B_REPORT|K8.B_REPORT]]
> >
> > ---
> >
> > 
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  [[RP9. THE RIEMANN SUBMISSION/0. A.P.X. RP9. THE RIEMANN SUBMISSION/RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---

<!-- RP9_NAVIGATION_END:A -->
