# B. PRIMARY DIFFERENTIATION & DOWNSTREAM DIFFERENTIATION

---

## DOCUMENT OVERVIEW


*This document defines two functional positions of differentiation: the meta-condition under which binary function becomes applicable and differentiation within the resulting generative and recursive domain.*

*It establishes the terminology and reading rule used to distinguish these positions.*

---

## 1. PRIMARY DIFFERENTIATION

Differentiation must exist as the necessary condition for any distinction to become observable or operationally applicable.

The first observable position therefore does not create differentiation. Its existence already implies differentiation, whether expressed through an observable distinction or through the potential possibility of its opposite.

**Primary Differentiation** identifies this meta-condition under which binary function becomes applicable.

---

## 2. DOWNSTREAM DIFFERENTIATION

Once binary function is applicable, the generative and recursive sequence operates downstream from the established meta-condition.

**Downstream Differentiation** identifies distinctions generated, established, or expressed within this operational domain.

The first differentiation generated within the domain is termed **First Operational Differentiation**.

Continued differentiation generated from the established sequence is termed **Subsequent Differentiation**.

---

## 3. FUNCTIONAL SEPARATION

The distinction concerns functional position:

| Term | Assigned position |
| --- | --- |
| **Primary Differentiation** | Meta-condition under which binary function becomes applicable |
| **Downstream Differentiation** | Differentiation within the established generative and recursive domain |

Their relation is:

$$
\boxed{
\begin{gathered}
\text{PRIMARY DIFFERENTIATION}\\
\text{META-CONDITION}\\
\downarrow\\
\text{BINARY FUNCTION}\\
\downarrow\\
\text{DOWNSTREAM DIFFERENTIATION}\\
\text{FIRST OPERATIONAL DIFFERENTIATION}\\
\downarrow\\
\text{SUBSEQUENT DIFFERENTIATION}
\end{gathered}
}
$$

The terms identify related positions and must remain distinct: the condition enabling binary operation precedes differentiation produced within that operation's domain.

---

## 4. READING RULE

Interpret differentiation according to its functional position:

- A condition under which binary function becomes applicable identifies **Primary Differentiation**.
- A distinction generated, established, or expressed within an operational, generative, or recursive sequence identifies **Downstream Differentiation**.

Within such a sequence, **first differentiation** means **First Operational Differentiation**, unless **Primary Differentiation** is explicitly stated.


