# RP9. SUBMISSION REVIEWER'S CODE GUIDE

---

## DOCUMENT OVERVIEW

*This guide defines the common method for locating, examining, and interpreting computational material.*

*It distinguishes reviewer guidance, executable implementation, recorded execution evidence, and declared validation boundaries.*

---

## 1. PURPOSE

Reviewer guides provide structured access to computational evidence.

They identify a program's assigned function, implementation, associated evidence, result conditions, and execution boundary so that these can be examined without inferring their intended roles from filenames alone.

The guide describes how to examine the material. Source code and recorded output remain the computational objects being examined.

---

## 2. INFORMATIONAL ROLES

| Material | Assigned role |
| --- | --- |
| **README** | Folder architecture, contents, and reading entry |
| **Common reviewer guide** | Shared examination method and authority rules |
| **Local reviewer guide** | Package-specific examination instructions |
| **Executable source** | Implemented computational operation |
| **Recorded output** | What the execution recorded |
| **Declared validation boundary** | Scope of the recorded result |

Each role remains distinct.

---

## 3. LOCAL GUIDE CONTENT

A package-specific guide identifies:

- the Python Code ID, official code title, and executable filename;
- the assigned computational function and implemented control structure;
- associated evidence files and their locations;
- recorded status fields and their meanings;
- conditions determining the result;
- declared execution domain;
- exactness and numerical representation boundaries;
- relevant input and comparison relationships;
- the source or output material governing each examination question.

The local applications are:

| Guide | Computational material |
| --- | --- |
| **K6. SUBMISSION REVIEWER'S CODE GUIDE** | K6. A — Scale Invariance Crosscheck; K6. B — Exact Binary Pulse Invariance Check |
| **K7. SUBMISSION REVIEWER'S CODE GUIDE** | K7 — P.B.F. Full Positional Genealogy — 100B Validator |
| **K8. SUBMISSION REVIEWER'S CODE GUIDE** | K8. A — P.B.F. ↔ Binary Pulse Operator Identity Validator; K8. B — P.B.F. Binary-Scale Invariance Validator; K8. C — P.B.F. Binary Structure → Base 10 Projection Lock Validator |

Detailed tests, output fields, execution domains, recorded results, and package-specific boundaries are addressed by the corresponding local guides and examined against their associated source and output material.

---

## 4. EXAMINATION METHOD

1. Identify the computational object and its assigned function through the local guide.
2. Locate the executable source.
3. Inspect the implemented operations and control conditions.
4. Locate the associated recorded output.
5. Inspect the recorded statuses and results.
6. Check the declared execution domain, exactness conditions, representation limits, and result scope.

This sequence describes examination order. It does not establish software dependencies or computational execution order.

An executable does not depend on its guide to run. A description of evidence does not establish the evidence's validity.

---

## 5. AUTHORITY AND DISCREPANCIES

| Question | Governing material |
| --- | --- |
| How is the material located and examined? | Reviewer guide |
| What operation is implemented? | Executable source |
| What result was recorded? | Recorded output |
| What domain and conditions limit the result? | Declared validation boundary, checked against source and output |

If a guide and its source differ about an implemented operation, the source governs the implementation question.

If a guide and its recorded output differ about an execution result, the output governs the recorded-result question.

Guides must remain synchronized with both. Discrepancies must be identified rather than resolved by treating the guide's description as computational evidence.

---

## 6. VALIDATION BOUNDARY

Reviewer guidance does not execute programs, generate evidence, alter source or output, or create new computational results.

It does not extend an executed domain or convert finite execution into a claim about an unexecuted domain.

K.6, K.7, and K.8 retain their distinct computational functions. Their presentation or examination order does not combine them into one program or create dependencies between independent executables.

Source inspection is required when implementation is examined. Recorded-output inspection is required when execution results are examined.

The guide provides access to these examinations. It does not perform the final determination for the complete Submission.



<!-- RP9_NAVIGATION_BEGIN:A -->

---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>
> ---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/K.6 CODE ARCHITECTURE/README —  K.6 CODE ARCHITECTURE|README —  K.6 CODE ARCHITECTURE]]
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/README — B. CODE ARCHITECTURE|README — B. CODE ARCHITECTURE]]
> >
> > ---
> >
> > $\boxed{\text{RP9. THE RIEMANN SUBMISSION READING ORDER}}$
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  [[RP9. THE RIEMANN SUBMISSION/0. A.P.X. RP9. THE RIEMANN SUBMISSION/RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---

<!-- RP9_NAVIGATION_END:A -->
