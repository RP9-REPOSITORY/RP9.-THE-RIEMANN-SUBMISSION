# README — K8. B

---

## DOCUMENT OVERVIEW

*This package checks exact binary-scale invariance of the half, three-quarter and one-quarter fraction families.*

*It constructs expanded numerator–denominator representations and tests quotient invariance, complementary closure, denominator alignment, the three-to-one numerator relation and full-frame closure.*

*Adjacent levels are checked separately for exact doubling of every numerator and denominator.*

*This README explains the local controls, execution requirements, evidence and recorded results.*

---

## 1. PACKAGE IDENTITY AND STRUCTURE

| Item | Identification |
|---|---|
| Python code ID | `K8. B` |
| RP9 code ID | `C.0096` |
| Official code title | **K8. P.B.F. BINARY-SCALE INVARIANCE VALIDATOR** |
| Source file | `1. Python/K8. B.py` |
| Program version | `2.1.0` |
| Author | Anton Wallin |

The local package is **K8. B**.

| Local location             | Function                                        |
| -------------------------- | ----------------------------------------------- |
| `README — K8. B.md`        | Package explanation and execution instructions. |
| `1. Python`                | Executable source.                              |
| `2. OUTPUT`                | Supplied execution records.                     |
| `3. FINAL REPORTS`         | Supplied final report copy.                     |

---

## 2. LOCAL FUNCTION AND DEFINITIONS

The binary factor at level $n$ is:

$$
f_n=2^n.
$$

The three expanded fraction families are:

$$
H_n=\frac{2^n}{2\cdot2^n},
\qquad
T_n=\frac{3\cdot2^n}{4\cdot2^n},
\qquad
Q_n=\frac{2^n}{4\cdot2^n}.
$$

Their expected exact values are:

$$
H_n=\frac12,
\qquad
T_n=\frac34,
\qquad
Q_n=\frac14.
$$

No output from another K.6, K.7 or K.8 script is required.

| Term | Implemented meaning |
|---|---|
| Level | Integer index $n$ controlling the factor $2^n$. |
| Binary factor | Factor multiplying the base numerator and denominator. |
| Expanded expression | Unreduced numerator–denominator representation retained as text. |
| Exact value | Reduced rational value constructed using `fractions.Fraction`. |
| Half family | Representations preserving $\frac12$. |
| Three-quarter family | Representations preserving $\frac34$. |
| One-quarter family | Representations preserving $\frac14$. |
| Complement relation | Three-quarter and one-quarter values sum to $1$. |
| Full frame | Sum of the expanded complementary numerators over their common denominator. |
| Scale transition | Doubling of each family's numerator and denominator between adjacent levels. |

The source defines `LEVEL_COUNT = 8`. Execution covers levels $0$ through $7$, with factors $1$ through $128$.

The full frame is:

$$
F_n=
\frac{3\cdot2^n+2^n}{4\cdot2^n}
=
\frac{4\cdot2^n}{4\cdot2^n}.
$$

The expanded complementary numerator relation is:

$$
\frac{3\cdot2^n}{2^n}=3.
$$

---

## 3. ARITHMETIC AND REPRESENTATION

Rational checks use `fractions.Fraction`. Integer comparisons check expanded numerators, denominators and scale progression.

No floating-point tolerance determines PASS or FAIL.

`expanded_fraction()` retains the expanded integers before reduction. For example:

$$
\frac34
\longrightarrow
\frac68
\longrightarrow
\frac{12}{16}.
$$

The corresponding `Fraction` objects all reduce to $\frac34$.

The JSON preserves both forms:

| Field | Recorded form |
|---|---|
| `three_quarter_expression` | Expanded numerator–denominator representation. |
| `three_quarter_exact` | Reduced exact value. |

The half and one-quarter families retain the same distinction, preserving scale information alongside quotient identity.

---

## 4. LEVEL CONTROL MATRIX

`build_level()` evaluates eight Boolean conditions at every level.

| Check key | PASS condition |
|---|---|
| `half_invariant` | Half value equals $\frac12$. |
| `three_quarter_invariant` | Three-quarter value equals $\frac34$. |
| `one_quarter_invariant` | One-quarter value equals $\frac14$. |
| `complement_relation` | Three-quarter plus one-quarter equals $1$. |
| `same_denominator` | Expanded complementary denominators match. |
| `binary_denominator` | Three-quarter denominator equals $4\cdot2^n$. |
| `three_to_one_ratio_pass` | Expanded complementary numerator ratio equals $3/1$. |
| `full_frame_pass` | Full-frame numerator equals its denominator. |

A level receives PASS only when all eight conditions hold.

Each level record also contains its index, binary factor, expanded expressions, reduced values and observed three-to-one ratio.

---

## 5. TRANSITION CONTROL MATRIX

`validate_transition()` reads adjacent expanded expressions and evaluates six conditions.

| Check key | PASS condition |
|---|---|
| `half_numerator_x2` | Current half numerator is twice the previous numerator. |
| `half_denominator_x2` | Current half denominator is twice the previous denominator. |
| `three_quarter_numerator_x2` | Current three-quarter numerator is twice the previous numerator. |
| `three_quarter_denominator_x2` | Current three-quarter denominator is twice the previous denominator. |
| `one_quarter_numerator_x2` | Current one-quarter numerator is twice the previous numerator. |
| `one_quarter_denominator_x2` | Current one-quarter denominator is twice the previous denominator. |

A transition receives PASS only when all six conditions hold.

Global PASS requires every one of the eight levels and seven transitions to PASS.

---

## 6. EXECUTED SCALE TABLE

| Level | Binary factor | Half | Three-quarter | One-quarter | Full frame | Status |
|---:|---:|---|---|---|---|:---:|
| $0$ | $1$ | $1/2$ | $3/4$ | $1/4$ | $4/4$ | PASS |
| $1$ | $2$ | $2/4$ | $6/8$ | $2/8$ | $8/8$ | PASS |
| $2$ | $4$ | $4/8$ | $12/16$ | $4/16$ | $16/16$ | PASS |
| $3$ | $8$ | $8/16$ | $24/32$ | $8/32$ | $32/32$ | PASS |
| $4$ | $16$ | $16/32$ | $48/64$ | $16/64$ | $64/64$ | PASS |
| $5$ | $32$ | $32/64$ | $96/128$ | $32/128$ | $128/128$ | PASS |
| $6$ | $64$ | $64/128$ | $192/256$ | $64/256$ | $256/256$ | PASS |
| $7$ | $128$ | $128/256$ | $384/512$ | $128/512$ | $512/512$ | PASS |

The reduced values remain $\frac12$, $\frac34$ and $\frac14$. The full frame remains equal to $1$.

---

## 7. EXECUTION REQUIREMENTS

Use Python $3.9$ or later for the built-in generic type annotations used in the source.

The script imports only standard-library modules. No third-party packages, external datasets, network access or command-line parameters are required.

Write access to the output directory is required.

The source constant `LEVEL_COUNT` determines the number of levels. There is no command-line option for changing it.

---

## 8. EXECUTION COMMAND

From the local **K8. B** package root, run:

```bash
python "1. Python/K8. B.py"
```

Where the executable is named `python3`, run:

```bash
python3 "1. Python/K8. B.py"
```

The script constructs the levels, validates adjacent transitions, determines the combined status and writes the output.

There is no interactive pause before exit.

---

## 9. EXECUTION AND OUTPUT LOCATION

The program:

1. Captures the local execution timestamp.
2. Resolves the script directory and creates its output directory.
3. Constructs levels with `build_level()`.
4. Validates adjacent levels with `validate_transition()`.
5. Determines level, transition and global status.
6. Writes JSON data, Markdown report and control text.
7. Prints the actual output directory and returns the exit code.

The output directory is resolved beside the script:

```python
root = base_dir()
output_dir = root / OUTPUT_DIR_NAME
```

With the source at `1. Python/K8. B.py`, a new run writes to:

`1. Python/2. OUTPUT/`

The supplied records are stored in `2. OUTPUT/`, with a report copy in `3. FINAL REPORTS/`.

The script does not automatically transfer newly generated files to those package-level folders.

The output location is independent of the terminal's working directory. Its resolved path is recorded in the JSON field `output_directory`.

Repeated execution overwrites the three named files.

---

## 10. OUTPUT FILES

| Filename | Function |
|---|---|
| `K8.B_DATA.json` | Code identity, version, timestamp, execution paths, level count, global status and all level and transition conditions. |
| `K8.B_REPORT.md` | Scale representations, invariant relations, transition results and validation scope. |
| `K8.B_CONTROL.txt` | Identity, timestamp, level and transition totals, PASS counts and global status. |

The JSON contains detailed Boolean results for tracing failed levels or transitions.

The control file's PRIMARY IDENTITIES lines are fixed descriptive text. Determine the execution result from its recorded PASS counts and global status together with the JSON conditions.

The supplied report copies in `2. OUTPUT` and `3. FINAL REPORTS` have the same SHA-256 checksum.

The script generates no separate trace file, execution log, checkpoint or error log.

---

## 11. RECORDED RESULT

The supplied records identify:

| Execution field    | Recorded value                     |
| ------------------ | ---------------------------------- |
| Program version    | `2.1.0`                            |
| Levels tested      | $8$                                |
| Level range        | $0$ through $7$                    |
| Level PASS         | $8$                                |
| Level FAIL         | $0$                                |
| Transitions tested | $7$                                |
| Transition PASS    | $7$                                |
| Transition FAIL    | $0$                                |
| Global status      | PASS                               |

Global PASS means that every defined level condition and adjacent-level doubling condition passed.

---

## 12. EXIT STATUS AND ERRORS

| Exit code | Meaning |
|---|---|
| `0` | Output writing completes and global status is PASS. |
| `1` | Output writing completes and at least one level or transition fails. |

The script has no custom exception handler. Runtime exceptions terminate through Python's normal error handling.

An interrupted output write may leave an incomplete file set. Assess completion using the exit status and generated records.

---

## 13. LOCAL INSPECTION AND REPRODUCTION

1. Inspect `1. Python/K8. B.py` for the level count, base fraction families and expansion rule.
2. Trace `expanded_fraction()` and `build_level()` to distinguish expanded representations from reduced values.
3. Inspect the eight level conditions.
4. Inspect the six adjacent-transition conditions.
5. Compare JSON level and transition records with the Markdown tables and control totals.
6. For reproduction, inspect newly generated records in the directory actually written by the script.

A level index and check key identify an individual level condition.

`from_level`, `to_level` and the transition check key identify an adjacent-level condition.

The local index and M.R.F. provide navigation and source identification. The Python source defines the operations; the output records their execution.

---

## 14. RESULT SCOPE

The supplied execution checks the defined half, three-quarter and one-quarter families across levels $0$ through $7$ and all seven adjacent transitions.

It records preserved quotient values, complementary closure, denominator alignment, the three-to-one numerator relation and full-frame closure.

These arithmetic invariance checks do not independently establish the generation of a particular numerical base.



<!-- RP9_NAVIGATION_BEGIN:A -->

---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>
> ---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/K.8 CODE ARCHITECTURE/K.8 CODE & OUTPUT/K8. B/1. Python/K8. B. PYTHON|K8. B. PYTHON]]
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/K.8 CODE ARCHITECTURE/K.8 CODE & OUTPUT/K8. A/3. FINAL REPORTS/K8.A_REPORT|K8.A_REPORT]]
> >
> > ---
> >
> > $\boxed{\text{RP9. THE RIEMANN SUBMISSION READING ORDER}}$
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  [[RP9. THE RIEMANN SUBMISSION/0. A.P.X. RP9. THE RIEMANN SUBMISSION/RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---

<!-- RP9_NAVIGATION_END:A -->
