# README — K.6 CODE ARCHITECTURE

---

## DOCUMENT OVERVIEW

*This **README** identifies the two K.6 programs, their source and recorded-output locations, reviewer guidance, and local access points.*

---

## PURPOSE

**K.6 CODE ARCHITECTURE** organises the K.6 computational package while preserving separate roles for executable sources, recorded outputs, final reports, and reviewer guidance.

---

## PROGRAMS

Both programs are located within **K.6 CODE & OUTPUT**.

| Folder / Code ID | Official code title | Executable location |
| --- | --- | --- |
| **K6. A** | **K6. SCALE INVARIANCE CROSSCHECK** | `K.6 CODE & OUTPUT/K6. A/1. Python/K6. A.py` |
| **K6. B** | **K6. EXACT BINARY PULSE INVARIANCE CHECK** | `K.6 CODE & OUTPUT/K6. B/1. Python/K6. B.py` |

The programs remain separate computational objects.

---

## SOURCE, OUTPUT, AND REPORTS

Each program folder contains:

| Local folder | Function |
| --- | --- |
| **1. Python** | Executable source |
| **2. OUTPUT** | Recorded execution material |
| **3. FINAL REPORTS** | Final report access |

The recorded files are:

| Program | Files in **2. OUTPUT** | File in **3. FINAL REPORTS** |
| --- | --- | --- |
| **K6. A** | `K6.A_CONTROL.txt`, `K6.A_DATA.json`, `K6.A_EXECUTION.log`, `K6.A_REPORT.md`, `K6.A_TRACE.json` | `K6.A_REPORT.md` |
| **K6. B** | `K6.B_CONTROL.log`, `K6.B_DATA.json`, `K6.B_REPORT.md` | `K6.B_REPORT.md` |

The local **README — K6. A** and **README — K6. B** provide orientation for their respective program folders.

---

## REVIEWER GUIDANCE

**RP9. K.6 REVIEWER'S GUIDE/K6. SUBMISSION REVIEWER'S CODE GUIDE.md** explains how to examine the two programs, their controls, evidence files, recorded results, and validation boundaries.

For computational examination:

1. Read the K.6 reviewer guide.
2. Examine the selected program's executable source.
3. Inspect its associated recorded output and final report.
4. Check the result conditions and declared validation boundaries.

---


## ARCHITECTURAL BOUNDARY

This README describes organisation and access. Computational operations, recorded results, and their validation boundaries must be examined through the source, output, and reviewer-guide material.

The folder architecture introduces no additional computational operation or result and does not extend either program's declared execution domain.





<!-- RP9_NAVIGATION_BEGIN:A -->

---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>
> ---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/K.6 CODE ARCHITECTURE/RP9. K.6 REVIEWER'S GUIDE/K6. SUBMISSION REVIEWER'S CODE GUIDE|K6. SUBMISSION REVIEWER'S CODE GUIDE]]
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 [[RP9. THE RIEMANN SUBMISSION/B. CODE ARCHITECTURE/RP9. SUBMISSION REVIEWER'S CODE GUIDE|RP9. SUBMISSION REVIEWER'S CODE GUIDE]]
> >
> > ---
> >
> > $\boxed{\text{RP9. THE RIEMANN SUBMISSION READING ORDER}}$
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  [[RP9. THE RIEMANN SUBMISSION/0. A.P.X. RP9. THE RIEMANN SUBMISSION/RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---

<!-- RP9_NAVIGATION_END:A -->
