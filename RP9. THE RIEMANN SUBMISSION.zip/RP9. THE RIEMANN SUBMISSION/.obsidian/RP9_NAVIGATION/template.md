
---
## $▶\ Next\ document$
---

> [!rp9-black]
>
> #### <center><code>$\boxed{\text{RP9.\ 🜁\ —\ Navigation}}$</code></center>
>
> ---
>
> ### $$\boxed{\text{RP9. THE RIEMANN SUBMISSION}}$$
>---
>
>#### <center><code>$\boxed{\text{ASCII ARCHITECTURE}}$</code></center>
>---
>```ASCII
> {{ASCII_ARCHITECTURE}}
> ```  
>---
>
> > $\boxed{\text{NEXT ▶}}$
> >
> > > 🔗 {{NEXT_LINK}}
> >
> > ---
> >
> > $\boxed{\text{◀ PREVIOUS}}$
> >
> > > 🔗 {{PREVIOUS_LINK}}
> >
> > ---
> >
> > 
> >
> > $\boxed{\text{⌂ HOME ⌂}}$
> >
> > > 🔗  **[[RP9. THE RIEMANN SUBMISSION READING ORDER|⌂ HOME — RP9. THE RIEMANN SUBMISSION READING ORDER]]**
>
> ---
>
> ### <center><code>$\boxed{\text{END OF DOCUMENT}}$</code></center>
>
> ---

---
