#!/usr/bin/env python3
"""Fixed submission-only navigation injection. Validates and backs up before writing."""
from __future__ import annotations
import datetime as dt
import os
import re
import shutil
import sys
from pathlib import Path

def windows_path(path: Path) -> Path:
    """Use Unicode Windows extended paths for deep source and backup trees."""
    path = path.resolve()
    if os.name != 'nt' or str(path).startswith('\\\\?\\'):
        return path
    value = str(path)
    if value.startswith('\\\\'):
        return Path('\\\\?\\UNC\\' + value[2:])
    return Path('\\\\?\\' + value)


SCRIPT = windows_path(Path(__file__))
TOOL_DIR = SCRIPT.parent
ROOT = TOOL_DIR.parent  # RP9_NAVIGATION is placed directly in the submission root.
APPENDIX = ROOT / 'ⓘ. Non-submission Appendix'
READING_ORDER = TOOL_DIR / 'RP9. THE RIEMANN SUBMISSION READING ORDER.md'
TEMPLATE = TOOL_DIR / 'template.md'
START = '<!-- RP9_NAVIGATION_BEGIN:{kind} -->'
END = '<!-- RP9_NAVIGATION_END:{kind} -->'
LINK = re.compile(r'\[\[([^\]|#]+)(?:\|[^\]]*)?\]\]')
NUMBERED = re.compile(r'(?m)^\s*>?\s*[├└│─ ]*\s*(\d{2})\.\s*🔗\s*')


def load(path: Path) -> tuple[str, str]:
    data = path.read_bytes()
    encoding = 'utf-8-sig' if data.startswith(b'\xef\xbb\xbf') else 'utf-8'
    return data.decode(encoding), encoding


def safe_path(link: str) -> Path:
    name = link.strip().replace('\\', '/')
    if name.startswith('/') or re.match(r'^[A-Za-z]:', name) or '..' in Path(name).parts:
        raise ValueError(f'Unsafe link: {link}')
    # Source lists may include the submission folder's name, or be root-relative.
    parts = name.split('/')
    if parts and parts[0] == ROOT.name:
        parts = parts[1:]
    if not parts or not any(parts):
        raise ValueError(f'Empty document path: {link}')
    p = ROOT.joinpath(*parts)
    if not name.lower().endswith('.md'):
        p = p.with_name(p.name + '.md')
    if not p.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError(f'Link escapes root: {link}')
    return p


def wiki(path: Path, label: str) -> str:
    # Use actual vault-relative paths when the vault can be detected.
    # Otherwise use the submission root as the vault root.
    vault = next((candidate for candidate in (ROOT, *ROOT.parents)
                  if (candidate / '.obsidian').is_dir()), ROOT)
    relative = path.relative_to(vault).as_posix()
    if relative.lower().endswith('.md'):
        relative = relative[:-3]
    return f'[[{relative}|{label}]]'


def collect() -> list[Path]:
    content, _ = load(READING_ORDER)
    matches, numbers = [], []
    # Read only numbered sequence entries, never sample menus or introductory links.
    for line in content.splitlines():
        number = NUMBERED.search(line)
        if number:
            targets = LINK.findall(line)
            if len(targets) != 1:
                raise ValueError('Each numbered entry must contain exactly one document link')
            numbers.append(int(number.group(1)))
            matches.extend(targets)
    if numbers != list(range(1, 54)):
        raise ValueError('The reading order must contain entries 01 through 53 exactly once and in order')
    documents, seen = [], set()
    for link in matches:
        target = safe_path(link)
        if target.suffix.lower() != '.md':
            raise ValueError(f'Non-Markdown target in reading order: {link}')
        if target.resolve() == READING_ORDER.resolve() or APPENDIX.resolve() in target.resolve().parents or TOOL_DIR.resolve() in target.resolve().parents:
            raise ValueError(f'Submission target must be outside the appendix: {link}')
        if target.resolve() in seen:
            raise ValueError(f'Duplicate submission document: {link}')
        if not target.is_file():
            raise FileNotFoundError(f'Listed Markdown target does not exist: {target}')
        seen.add(target.resolve())
        documents.append(target)
    return documents


def document_architecture(document: Path) -> str:
    """Show the actual folder chain from the submission root to this document."""
    parts = document.relative_to(ROOT).parts
    lines = [f'📁 {ROOT.name}']
    for depth, name in enumerate(parts):
        if depth == len(parts) - 1:
            label = Path(name).stem
        else:
            label = ('📁 ' if depth == 0 else '📂 ') + name
        lines.append('    ' * depth + '└─ ' + label)
    return '\n'.join(lines)


def render(template: str, prev: Path | None, nxt: Path | None, document: Path) -> str:
    for token in ('{{NEXT_LINK}}', '{{PREVIOUS_LINK}}'):
        if template.count(token) != 1:
            raise ValueError(f'Template must contain exactly one {token}')
    # Architecture is optional for compatibility with existing templates.
    # Repeat the exact callout prefix on every generated architecture line.
    token = '{{ASCII_ARCHITECTURE}}'
    if template.count(token) > 1:
        raise ValueError('Template contains duplicate ASCII_ARCHITECTURE placeholders')
    if token in template:
        pattern = re.compile(r'(?m)^([ \t]*(?:>[ \t]*)*)\{\{ASCII_ARCHITECTURE\}\}[ \t]*$')
        match = pattern.search(template)
        if not match:
            raise ValueError('ASCII_ARCHITECTURE must be placed on its own template line')
        prefix = match.group(1)
        tree = '\n'.join(prefix + line for line in document_architecture(document).splitlines())
        template = template[:match.start()] + tree + template[match.end():]
    # Fixed HOME and all remaining template content are left untouched.
    values = {
        '{{NEXT_LINK}}': wiki(nxt, nxt.stem) if nxt else wiki(READING_ORDER, READING_ORDER.stem),
        '{{PREVIOUS_LINK}}': wiki(prev, prev.stem) if prev else wiki(READING_ORDER, READING_ORDER.stem),
    }
    for token, value in values.items():
        template = template.replace(token, value)
    return f'{START.format(kind="A")}\n{template}\n{END.format(kind="A")}'


def prepare(original: str, kind: str, block: str, allow_existing: bool) -> tuple[str, str]:
    newline = '\r\n' if '\r\n' in original else '\n'
    block = block.replace('\r\n', '\n').replace('\n', newline)
    start, end = START.format(kind=kind), END.format(kind=kind)
    if (start in original) != (end in original):
        raise ValueError('Incomplete managed navigation markers')
    if start in original:
        if original.count(start) != 1 or original.count(end) != 1:
            raise ValueError('Duplicate managed navigation markers')
        begin = original.index(start)
        end_at = original.index(end)
        if end_at < begin:
            raise ValueError('Managed navigation markers are in the wrong order')
        finish = end_at + len(end)
        changed = original[:begin] + block + original[finish:]
        return changed, 'UPDATE'
    # Unmarked existing material belongs to the source document and is preserved.
    # Only RP9_NAVIGATION_BEGIN:A / END:A identify blocks managed by this tool.
    newline = '\r\n' if '\r\n' in original else '\n'
    return original + newline * 2 + block + newline, 'INSERT'


def main() -> int:
    print('RP9 SUBMISSION NAVIGATION — AUTOMATIC INJECTION')
    print(f'REPOSITORY ROOT: {ROOT}')
    print(f'READING ORDER: {READING_ORDER}')
    print(f'TEMPLATE: {TEMPLATE}')
    plan = []
    try:
        if not READING_ORDER.is_file() or not TEMPLATE.is_file():
            raise FileNotFoundError('Keep RP9. THE RIEMANN SUBMISSION READING ORDER.md and template.md beside inject_navigation.py')
        documents = collect()
        template, _ = load(TEMPLATE)
        for i, path in enumerate(documents):
            original, encoding = load(path)
            block = render(template, documents[i-1] if i else None,
                           documents[i+1] if i+1 < len(documents) else None, path)
            updated, action = prepare(original, 'A', block, False)
            if updated != original:
                plan.append((path, original, updated, encoding))
            print(f'{i+1:02d}/53 {action if updated != original else "UNCHANGED"}: {path.relative_to(ROOT)}')
    except (OSError, UnicodeError, ValueError) as error:
        print(f'ABORTED BEFORE WRITING: {error}', file=sys.stderr)
        return 1
    print(f'VALIDATED: 53 documents. PLANNED CHANGES: {len(plan)}')
    if not plan:
        print('COMPLETE: All navigation blocks are already up to date.')
        return 0
    backup = TOOL_DIR / 'NAVIGATION_BACKUPS' / dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    # Finish all backups before writing to any document.
    try:
        for path, *_ in plan:
            destination = backup / path.relative_to(ROOT)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination)
        for path, original, updated, encoding in plan:
            temporary = path.with_name(path.name + '.rp9_nav_tmp')
            temporary.write_bytes(updated.encode(encoding))
            temporary.replace(path)
    except OSError as error:
        print(f'WRITE FAILED: {error}. Originals backed up under {backup}', file=sys.stderr)
        return 2
    print(f'COMPLETE: {len(plan)} documents updated. BACKUPS: {backup}')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (KeyboardInterrupt, EOFError):
        print("\nInterrupted.")
        raise SystemExit(1)
