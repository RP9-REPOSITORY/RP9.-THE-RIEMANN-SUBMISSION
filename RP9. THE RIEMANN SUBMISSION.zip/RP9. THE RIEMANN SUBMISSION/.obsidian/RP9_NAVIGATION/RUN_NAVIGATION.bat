@echo off
setlocal EnableExtensions
if "%RP9_FLAT_NAV_WINDOW%"=="1" goto MAIN
set "RP9_FLAT_NAV_WINDOW=1"
start "RP9 Submission Navigation" cmd.exe /d /k ""%~f0""
exit /b
:MAIN
cd /d "%~dp0"
echo RP9 SUBMISSION NAVIGATION - SINGLE AUTOMATIC RUN
echo.
if not exist "%~dp0inject_navigation.py" goto NO_SCRIPT
python -c "import sys; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 goto USE_PYTHON
py -3 -c "import sys; assert sys.version_info >= (3,9)" >nul 2>&1
if not errorlevel 1 goto USE_PY
echo ERROR: No working Python 3.9 or newer was found.
exit /b 1
:USE_PYTHON
python "%~dp0inject_navigation.py"
goto RESULT
:USE_PY
py -3 "%~dp0inject_navigation.py"
goto RESULT
:RESULT
set "RP9_RESULT=%ERRORLEVEL%"
echo.
echo Python exit code: %RP9_RESULT%
echo The window remains open for inspection.
exit /b %RP9_RESULT%
:NO_SCRIPT
echo ERROR: Keep all four package files together in RP9_NAVIGATION.
exit /b 1
